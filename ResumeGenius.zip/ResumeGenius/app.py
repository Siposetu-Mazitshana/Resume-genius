import streamlit as st
import json
from datetime import datetime
from utils.ai_generator import AIGenerator
from utils.export_manager import ExportManager
from utils.template_manager import TemplateManager
from utils.storage_manager import StorageManager
from utils.offline_manager import OfflineManager
from pages.landing import render_landing_page, render_ai_suggestions, render_template_showcase
from pages.settings import render_settings_page, render_help_page

# Initialize components
@st.cache_resource
def initialize_components():
    ai_gen = AIGenerator()
    export_mgr = ExportManager()
    template_mgr = TemplateManager()
    storage_mgr = StorageManager()
    offline_mgr = OfflineManager()
    return ai_gen, export_mgr, template_mgr, storage_mgr, offline_mgr

def main():
    st.set_page_config(
        page_title="TAC Resume Builder",
        page_icon="📄",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Initialize components
    ai_gen, export_mgr, template_mgr, storage_mgr, offline_mgr = initialize_components()
    
    # Initialize session state
    if 'resume_data' not in st.session_state:
        st.session_state.resume_data = storage_mgr.load_resume_data()
    
    if 'current_step' not in st.session_state:
        st.session_state.current_step = 0
    
    if 'selected_template' not in st.session_state:
        st.session_state.selected_template = 'modern'
    
    if 'current_page' not in st.session_state:
        st.session_state.current_page = 'landing'
    
    # Navigation
    with st.sidebar:
        st.markdown("## 🎯 TAC Resume Builder")
        
        # Main navigation
        page_options = {
            'landing': '🏠 Home',
            'builder': '📝 Resume Builder', 
            'templates': '🎨 Templates',
            'ai_suggestions': '🧠 AI Assistant',
            'settings': '⚙️ Settings',
            'help': '📚 Help'
        }
        
        selected_page = st.selectbox(
            "Navigate to:",
            options=list(page_options.keys()),
            format_func=lambda x: page_options[x],
            index=list(page_options.keys()).index(st.session_state.current_page)
        )
        
        if selected_page != st.session_state.current_page:
            st.session_state.current_page = selected_page
            st.rerun()
        
        st.divider()
        
        # Show quick stats if on builder page
        if st.session_state.current_page == 'builder':
            stats = storage_mgr.get_resume_statistics()
            st.markdown("### 📊 Progress")
            st.progress(stats['completion_percentage'] / 100)
            st.caption(f"{stats['completion_percentage']:.0f}% Complete")
            
            st.divider()
    
    # Route to appropriate page
    if st.session_state.current_page == 'landing':
        render_landing_page()
    elif st.session_state.current_page == 'builder':
        render_builder_page(ai_gen, export_mgr, template_mgr, storage_mgr, offline_mgr)
    elif st.session_state.current_page == 'templates':
        render_template_showcase()
    elif st.session_state.current_page == 'ai_suggestions':
        render_ai_suggestions()
    elif st.session_state.current_page == 'settings':
        render_settings_page()
    elif st.session_state.current_page == 'help':
        render_help_page()

def render_builder_page(ai_gen, export_mgr, template_mgr, storage_mgr, offline_mgr):
    """Render the main resume builder interface"""
    
    # Header
    st.title("📝 Resume Builder")
    st.markdown("Build your professional resume step by step")
    
    # Step navigation and quick actions
    with st.sidebar:
        st.header("📋 Resume Sections")
        
        steps = [
            "Personal Information",
            "Professional Summary", 
            "Work Experience",
            "Education",
            "Skills",
            "Additional Sections",
            "Template & Export"
        ]
        
        current_step = st.selectbox(
            "Choose Section:",
            range(len(steps)),
            format_func=lambda x: f"{x+1}. {steps[x]}",
            index=st.session_state.current_step
        )
        st.session_state.current_step = current_step
        
        st.divider()
        
        # Template selection
        st.header("🎨 Active Template")
        template_names = list(template_mgr.get_available_templates().keys())
        selected_template = st.selectbox(
            "Template:",
            template_names,
            index=template_names.index(st.session_state.selected_template)
        )
        st.session_state.selected_template = selected_template
        
        st.divider()
        
        # Quick Export Options
        st.header("📄 Quick Export")
        
        export_settings = st.session_state.get('export_settings', {
            'color_scheme': 'Blue',
            'font_family': 'Arial',
            'font_size': 'Medium',
            'layout_density': 'Standard'
        })
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("📄 PDF", use_container_width=True):
                try:
                    pdf_data = export_mgr.export_to_pdf(
                        st.session_state.resume_data, 
                        st.session_state.selected_template, 
                        export_settings
                    )
                    st.download_button(
                        label="Download PDF",
                        data=pdf_data,
                        file_name=f"resume_{st.session_state.selected_template}.pdf",
                        mime="application/pdf"
                    )
                except Exception as e:
                    st.error(f"PDF export failed: {str(e)}")
        
        with col2:
            if st.button("📝 DOCX", use_container_width=True):
                try:
                    docx_data = export_mgr.export_to_docx(
                        st.session_state.resume_data, 
                        st.session_state.selected_template, 
                        export_settings
                    )
                    st.download_button(
                        label="Download DOCX",
                        data=docx_data,
                        file_name=f"resume_{st.session_state.selected_template}.docx",
                        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    )
                except Exception as e:
                    st.error(f"DOCX export failed: {str(e)}")
        
        if st.button("🌐 HTML", use_container_width=True):
            try:
                html_data = export_mgr.export_to_html(
                    st.session_state.resume_data, 
                    st.session_state.selected_template, 
                    export_settings
                )
                st.download_button(
                    label="Download HTML",
                    data=html_data,
                    file_name=f"resume_{st.session_state.selected_template}.html",
                    mime="text/html"
                )
            except Exception as e:
                st.error(f"HTML export failed: {str(e)}")
        
        # Offline Package Export
        if st.button("📦 Offline Package", use_container_width=True):
            try:
                offline_package = offline_mgr.create_offline_package(st.session_state.resume_data)
                
                # Create a ZIP-like experience by offering multiple downloads
                st.success("Offline package ready! Download all files:")
                
                for filename, content in offline_package.items():
                    if filename.endswith('.html'):
                        mime_type = "text/html"
                    elif filename.endswith('.css'):
                        mime_type = "text/css"
                    else:
                        mime_type = "text/plain"
                    
                    st.download_button(
                        label=f"📄 {filename}",
                        data=content,
                        file_name=filename,
                        mime=mime_type,
                        key=f"download_{filename}"
                    )
                
                # Show offline stats
                offline_stats = offline_mgr.get_offline_stats(st.session_state.resume_data)
                st.info("✅ Fully offline compatible - works without internet!")
                
            except Exception as e:
                st.error(f"Offline package creation failed: {str(e)}")
        
        st.divider()
        
        # Quick actions
        st.header("⚡ Quick Actions")
        if st.button("💾 Save Progress", use_container_width=True):
            storage_mgr.save_resume_data(st.session_state.resume_data)
            st.success("Progress saved!")
        
        if st.button("🔄 Load Saved Data", use_container_width=True):
            st.session_state.resume_data = storage_mgr.load_resume_data()
            st.success("Data loaded!")
            st.rerun()
    
    # Main content area with AI suggestions
    col1, col2 = st.columns([3, 2])
    
    with col1:
        # AI suggestions for current step
        render_step_ai_suggestions(current_step, ai_gen)
        
        st.header(f"📝 {steps[current_step]}")
        
        # Render current step
        if current_step == 0:
            render_personal_info(ai_gen)
        elif current_step == 1:
            render_professional_summary(ai_gen)
        elif current_step == 2:
            render_work_experience(ai_gen)
        elif current_step == 3:
            render_education(ai_gen)
        elif current_step == 4:
            render_skills(ai_gen)
        elif current_step == 5:
            render_additional_sections(ai_gen)
        elif current_step == 6:
            render_template_export(export_mgr, template_mgr)
    
    with col2:
        st.header("👁️ Live Preview")
        render_preview(template_mgr)

def render_step_ai_suggestions(current_step, ai_gen):
    """Render contextual AI suggestions for the current step"""
    
    suggestions_map = {
        0: {
            'title': '📋 Personal Information Tips',
            'tips': [
                'Use a professional email address',
                'Include your LinkedIn profile URL',
                'Add your location (city, state)',
                'Ensure phone number is current'
            ]
        },
        1: {
            'title': '✨ Professional Summary Tips',
            'tips': [
                'Keep it 3-4 sentences maximum',
                'Highlight your key achievements',
                'Include years of experience',
                'Use AI generation for best results'
            ]
        },
        2: {
            'title': '💼 Work Experience Tips',
            'tips': [
                'Start bullet points with action verbs',
                'Quantify achievements with numbers',
                'Use AI to generate compelling bullets',
                'List jobs in reverse chronological order'
            ]
        },
        3: {
            'title': '🎓 Education Tips',
            'tips': [
                'Include relevant coursework for recent grads',
                'Add GPA if 3.5 or higher',
                'List honors and awards',
                'Include graduation date'
            ]
        },
        4: {
            'title': '🛠️ Skills Tips',
            'tips': [
                'Use AI to suggest relevant skills',
                'Organize by category',
                'Include both technical and soft skills',
                'Match skills to job requirements'
            ]
        },
        5: {
            'title': '📂 Additional Sections Tips',
            'tips': [
                'Add projects for technical roles',
                'Include certifications if relevant',
                'Add volunteer work if applicable',
                'Keep sections concise and relevant'
            ]
        },
        6: {
            'title': '🎨 Template & Export Tips',
            'tips': [
                'Choose template based on your industry',
                'Customize colors to match preferences',
                'PDF format is most widely accepted',
                'Test different templates with your content'
            ]
        }
    }
    
    step_info = suggestions_map.get(current_step, suggestions_map[0])
    
    with st.expander(step_info['title'], expanded=False):
        for tip in step_info['tips']:
            st.markdown(f"• {tip}")
        
        # Add contextual AI suggestions based on current data
        if current_step == 1 and 'resume_data' in st.session_state:
            if not st.session_state.resume_data.get('summary'):
                st.info("💡 Use the AI generation feature below to create a compelling professional summary!")
        
        elif current_step == 2:
            work_exp = st.session_state.get('resume_data', {}).get('work_experience', [])
            if len(work_exp) == 0:
                st.info("💡 Add your most recent job first, then work backwards chronologically.")
        
        elif current_step == 4:
            skills = st.session_state.get('resume_data', {}).get('skills', {})
            if len(skills) == 0:
                st.info("💡 Use AI skill suggestions to quickly populate relevant skills for your target role.")

def render_personal_info(ai_gen):
    """Render personal information form"""
    st.markdown("Enter your basic contact information:")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.session_state.resume_data['personal']['full_name'] = st.text_input(
            "Full Name *", 
            value=st.session_state.resume_data['personal'].get('full_name', '')
        )
        
        st.session_state.resume_data['personal']['email'] = st.text_input(
            "Email Address *", 
            value=st.session_state.resume_data['personal'].get('email', '')
        )
        
        st.session_state.resume_data['personal']['phone'] = st.text_input(
            "Phone Number", 
            value=st.session_state.resume_data['personal'].get('phone', '')
        )
    
    with col2:
        st.session_state.resume_data['personal']['location'] = st.text_input(
            "Location (City, State)", 
            value=st.session_state.resume_data['personal'].get('location', '')
        )
        
        st.session_state.resume_data['personal']['linkedin'] = st.text_input(
            "LinkedIn URL", 
            value=st.session_state.resume_data['personal'].get('linkedin', '')
        )
        
        st.session_state.resume_data['personal']['website'] = st.text_input(
            "Website/Portfolio", 
            value=st.session_state.resume_data['personal'].get('website', '')
        )

def render_professional_summary(ai_gen):
    """Render professional summary section with AI assistance"""
    st.markdown("Create a compelling professional summary:")
    
    # Input for AI generation
    col1, col2 = st.columns([2, 1])
    
    with col1:
        job_title = st.text_input(
            "Target Job Title", 
            placeholder="e.g., Software Engineer, Marketing Manager"
        )
        
        years_experience = st.number_input(
            "Years of Experience", 
            min_value=0, 
            max_value=50, 
            value=0
        )
    
    with col2:
        industry = st.selectbox(
            "Industry",
            ["Technology", "Healthcare", "Finance", "Marketing", "Education", 
             "Manufacturing", "Retail", "Consulting", "Non-profit", "Other"]
        )
        
        if st.button("🤖 Generate AI Summary", use_container_width=True):
            if job_title:
                with st.spinner("Generating professional summary..."):
                    summary = ai_gen.generate_professional_summary(
                        job_title, years_experience, industry, 
                        st.session_state.resume_data
                    )
                    st.session_state.resume_data['summary'] = summary
                    st.success("AI summary generated!")
                    st.rerun()
    
    # Summary text area
    st.session_state.resume_data['summary'] = st.text_area(
        "Professional Summary",
        value=st.session_state.resume_data.get('summary', ''),
        height=150,
        help="A brief overview of your professional background and key qualifications"
    )

def render_work_experience(ai_gen):
    """Render work experience section with AI assistance"""
    st.markdown("Add your work experience:")
    
    if 'work_experience' not in st.session_state.resume_data:
        st.session_state.resume_data['work_experience'] = []
    
    # Add new experience
    with st.expander("➕ Add New Work Experience", expanded=len(st.session_state.resume_data['work_experience']) == 0):
        col1, col2 = st.columns(2)
        
        with col1:
            job_title = st.text_input("Job Title", key="new_job_title")
            company = st.text_input("Company Name", key="new_company")
            start_date = st.date_input("Start Date", key="new_start_date")
        
        with col2:
            location = st.text_input("Location", key="new_location")
            current_job = st.checkbox("Current Position", key="new_current")
            end_date = None if current_job else st.date_input("End Date", key="new_end_date")
        
        # AI-powered job description
        col1, col2 = st.columns([2, 1])
        
        with col1:
            job_description = st.text_area(
                "Job Description (brief overview for AI)",
                key="new_job_desc",
                height=100,
                placeholder="Briefly describe your role and key responsibilities..."
            )
        
        with col2:
            if st.button("🤖 Generate Bullet Points", key="gen_bullets"):
                if job_title and job_description:
                    with st.spinner("Generating bullet points..."):
                        bullets = ai_gen.generate_job_bullets(job_title, job_description, company)
                        st.session_state.temp_bullets = bullets
                        st.success("Bullet points generated!")
        
        # Display generated bullets
        if hasattr(st.session_state, 'temp_bullets'):
            st.markdown("**Generated Bullet Points:**")
            bullets_text = st.text_area(
                "Edit bullet points:",
                value='\n'.join(st.session_state.temp_bullets),
                height=150,
                key="edit_bullets"
            )
            final_bullets = [bullet.strip() for bullet in bullets_text.split('\n') if bullet.strip()]
        else:
            final_bullets = []
        
        if st.button("✅ Add Experience", type="primary"):
            if job_title and company:
                experience = {
                    'job_title': job_title,
                    'company': company,
                    'location': location,
                    'start_date': start_date.strftime('%Y-%m-%d'),
                    'end_date': end_date.strftime('%Y-%m-%d') if end_date else 'Present',
                    'current': current_job,
                    'bullets': final_bullets
                }
                st.session_state.resume_data['work_experience'].append(experience)
                if hasattr(st.session_state, 'temp_bullets'):
                    del st.session_state.temp_bullets
                st.success("Experience added!")
                st.rerun()
    
    # Display existing experiences
    for i, exp in enumerate(st.session_state.resume_data['work_experience']):
        with st.expander(f"{exp['job_title']} at {exp['company']}", expanded=False):
            col1, col2, col3 = st.columns([3, 1, 1])
            
            with col1:
                st.write(f"**Location:** {exp['location']}")
                st.write(f"**Duration:** {exp['start_date']} to {exp['end_date']}")
            
            with col2:
                if st.button("✏️ Edit", key=f"edit_{i}"):
                    st.info("Feature coming soon!")
            
            with col3:
                if st.button("🗑️ Delete", key=f"delete_{i}"):
                    st.session_state.resume_data['work_experience'].pop(i)
                    st.rerun()
            
            if exp['bullets']:
                st.markdown("**Key Achievements:**")
                for bullet in exp['bullets']:
                    st.markdown(f"• {bullet}")

def render_education(ai_gen):
    """Render education section"""
    st.markdown("Add your educational background:")
    
    if 'education' not in st.session_state.resume_data:
        st.session_state.resume_data['education'] = []
    
    # Add new education
    with st.expander("➕ Add Education", expanded=len(st.session_state.resume_data['education']) == 0):
        col1, col2 = st.columns(2)
        
        with col1:
            degree = st.text_input("Degree", key="new_degree")
            school = st.text_input("School/University", key="new_school")
            graduation_date = st.date_input("Graduation Date", key="new_grad_date")
        
        with col2:
            major = st.text_input("Major/Field of Study", key="new_major")
            gpa = st.text_input("GPA (optional)", key="new_gpa")
            honors = st.text_input("Honors/Awards (optional)", key="new_honors")
        
        if st.button("✅ Add Education", type="primary"):
            if degree and school:
                education = {
                    'degree': degree,
                    'school': school,
                    'major': major,
                    'graduation_date': graduation_date.strftime('%Y-%m-%d'),
                    'gpa': gpa,
                    'honors': honors
                }
                st.session_state.resume_data['education'].append(education)
                st.success("Education added!")
                st.rerun()
    
    # Display existing education
    for i, edu in enumerate(st.session_state.resume_data['education']):
        with st.expander(f"{edu['degree']} - {edu['school']}", expanded=False):
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.write(f"**Major:** {edu['major']}")
                st.write(f"**Graduated:** {edu['graduation_date']}")
                if edu['gpa']:
                    st.write(f"**GPA:** {edu['gpa']}")
                if edu['honors']:
                    st.write(f"**Honors:** {edu['honors']}")
            
            with col2:
                if st.button("🗑️ Delete", key=f"delete_edu_{i}"):
                    st.session_state.resume_data['education'].pop(i)
                    st.rerun()

def render_skills(ai_gen):
    """Render skills section with AI suggestions"""
    st.markdown("Organize your skills by category:")
    
    if 'skills' not in st.session_state.resume_data:
        st.session_state.resume_data['skills'] = {}
    
    # AI skill suggestions
    col1, col2 = st.columns([2, 1])
    
    with col1:
        job_role = st.text_input(
            "Target Job Role", 
            placeholder="e.g., Software Developer, Data Analyst"
        )
    
    with col2:
        if st.button("🤖 Suggest Skills", use_container_width=True):
            if job_role:
                with st.spinner("Generating skill suggestions..."):
                    suggested_skills = ai_gen.suggest_skills(job_role)
                    st.session_state.suggested_skills = suggested_skills
                    st.success("Skills suggested!")
    
    # Display suggested skills
    if hasattr(st.session_state, 'suggested_skills'):
        st.markdown("**AI Suggested Skills:**")
        for category, skills in st.session_state.suggested_skills.items():
            st.markdown(f"**{category}:** {', '.join(skills)}")
        
        if st.button("✅ Add Suggested Skills"):
            for category, skills in st.session_state.suggested_skills.items():
                if category not in st.session_state.resume_data['skills']:
                    st.session_state.resume_data['skills'][category] = []
                st.session_state.resume_data['skills'][category].extend(skills)
            del st.session_state.suggested_skills
            st.success("Skills added!")
            st.rerun()
    
    # Manual skill entry
    st.markdown("**Add Skills Manually:**")
    
    skill_categories = ["Technical Skills", "Programming Languages", "Tools & Software", 
                       "Soft Skills", "Languages", "Certifications"]
    
    selected_category = st.selectbox("Category", skill_categories)
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        new_skills = st.text_input(
            "Skills (comma-separated)",
            placeholder="e.g., Python, JavaScript, React"
        )
    
    with col2:
        if st.button("➕ Add"):
            if new_skills:
                if selected_category not in st.session_state.resume_data['skills']:
                    st.session_state.resume_data['skills'][selected_category] = []
                skills_list = [skill.strip() for skill in new_skills.split(',')]
                st.session_state.resume_data['skills'][selected_category].extend(skills_list)
                st.success("Skills added!")
                st.rerun()
    
    # Display current skills
    if st.session_state.resume_data['skills']:
        st.markdown("**Current Skills:**")
        for category, skills in st.session_state.resume_data['skills'].items():
            if skills:
                col1, col2 = st.columns([4, 1])
                with col1:
                    st.markdown(f"**{category}:** {', '.join(skills)}")
                with col2:
                    if st.button("🗑️", key=f"delete_skill_cat_{category}"):
                        del st.session_state.resume_data['skills'][category]
                        st.rerun()

def render_additional_sections(ai_gen):
    """Render additional sections like projects, certifications, etc."""
    st.markdown("Add additional sections to strengthen your resume:")
    
    # Projects section
    st.subheader("📁 Projects")
    if 'projects' not in st.session_state.resume_data:
        st.session_state.resume_data['projects'] = []
    
    with st.expander("➕ Add Project", expanded=False):
        col1, col2 = st.columns(2)
        
        with col1:
            project_name = st.text_input("Project Name", key="new_project_name")
            project_tech = st.text_input("Technologies Used", key="new_project_tech")
        
        with col2:
            project_url = st.text_input("Project URL (optional)", key="new_project_url")
            project_date = st.date_input("Completion Date", key="new_project_date")
        
        project_description = st.text_area(
            "Project Description",
            key="new_project_desc",
            height=100
        )
        
        if st.button("✅ Add Project", type="primary"):
            if project_name and project_description:
                project = {
                    'name': project_name,
                    'technologies': project_tech,
                    'url': project_url,
                    'date': project_date.strftime('%Y-%m-%d'),
                    'description': project_description
                }
                st.session_state.resume_data['projects'].append(project)
                st.success("Project added!")
                st.rerun()
    
    # Display projects
    for i, project in enumerate(st.session_state.resume_data['projects']):
        with st.expander(f"{project['name']}", expanded=False):
            st.write(f"**Technologies:** {project['technologies']}")
            st.write(f"**Date:** {project['date']}")
            if project['url']:
                st.write(f"**URL:** {project['url']}")
            st.write(f"**Description:** {project['description']}")
            
            if st.button("🗑️ Delete Project", key=f"delete_project_{i}"):
                st.session_state.resume_data['projects'].pop(i)
                st.rerun()
    
    # Certifications section
    st.subheader("🏆 Certifications")
    if 'certifications' not in st.session_state.resume_data:
        st.session_state.resume_data['certifications'] = []
    
    with st.expander("➕ Add Certification", expanded=False):
        col1, col2 = st.columns(2)
        
        with col1:
            cert_name = st.text_input("Certification Name", key="new_cert_name")
            cert_issuer = st.text_input("Issuing Organization", key="new_cert_issuer")
        
        with col2:
            cert_date = st.date_input("Date Obtained", key="new_cert_date")
            cert_expiry = st.date_input("Expiry Date (optional)", key="new_cert_expiry")
        
        cert_id = st.text_input("Certification ID (optional)", key="new_cert_id")
        
        if st.button("✅ Add Certification", type="primary"):
            if cert_name and cert_issuer:
                certification = {
                    'name': cert_name,
                    'issuer': cert_issuer,
                    'date': cert_date.strftime('%Y-%m-%d'),
                    'expiry': cert_expiry.strftime('%Y-%m-%d') if cert_expiry else '',
                    'id': cert_id
                }
                st.session_state.resume_data['certifications'].append(certification)
                st.success("Certification added!")
                st.rerun()
    
    # Display certifications
    for i, cert in enumerate(st.session_state.resume_data['certifications']):
        with st.expander(f"{cert['name']}", expanded=False):
            st.write(f"**Issuer:** {cert['issuer']}")
            st.write(f"**Date:** {cert['date']}")
            if cert['expiry']:
                st.write(f"**Expires:** {cert['expiry']}")
            if cert['id']:
                st.write(f"**ID:** {cert['id']}")
            
            if st.button("🗑️ Delete Certification", key=f"delete_cert_{i}"):
                st.session_state.resume_data['certifications'].pop(i)
                st.rerun()

def render_template_export(export_mgr, template_mgr):
    """Render template customization and export options"""
    st.markdown("Customize your template and export your resume:")
    
    # Template customization
    st.subheader("🎨 Template Customization")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Color scheme
        color_scheme = st.selectbox(
            "Color Scheme",
            ["Blue", "Green", "Purple", "Red", "Orange", "Teal", "Gray"]
        )
        
        # Font selection
        font_family = st.selectbox(
            "Font Family",
            ["Arial", "Helvetica", "Times New Roman", "Calibri", "Georgia"]
        )
    
    with col2:
        # Font size
        font_size = st.selectbox(
            "Font Size",
            ["Small", "Medium", "Large"]
        )
        
        # Layout density
        layout_density = st.selectbox(
            "Layout Density",
            ["Compact", "Standard", "Spacious"]
        )
    
    # Update template settings
    template_settings = {
        'color_scheme': color_scheme,
        'font_family': font_family,
        'font_size': font_size,
        'layout_density': layout_density
    }
    
    # Export section
    st.subheader("📤 Export Resume")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📄 Export as PDF", use_container_width=True, type="primary"):
            try:
                pdf_data = export_mgr.export_to_pdf(
                    st.session_state.resume_data,
                    st.session_state.selected_template,
                    template_settings
                )
                st.download_button(
                    label="💾 Download PDF",
                    data=pdf_data,
                    file_name=f"{st.session_state.resume_data['personal'].get('full_name', 'Resume')}_Resume.pdf",
                    mime="application/pdf",
                    use_container_width=True
                )
            except Exception as e:
                st.error(f"Error generating PDF: {str(e)}")
    
    with col2:
        if st.button("📝 Export as DOCX", use_container_width=True, type="primary"):
            try:
                docx_data = export_mgr.export_to_docx(
                    st.session_state.resume_data,
                    st.session_state.selected_template,
                    template_settings
                )
                st.download_button(
                    label="💾 Download DOCX",
                    data=docx_data,
                    file_name=f"{st.session_state.resume_data['personal'].get('full_name', 'Resume')}_Resume.docx",
                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    use_container_width=True
                )
            except Exception as e:
                st.error(f"Error generating DOCX: {str(e)}")
    
    with col3:
        if st.button("🌐 Export as HTML", use_container_width=True, type="primary"):
            try:
                html_data = export_mgr.export_to_html(
                    st.session_state.resume_data,
                    st.session_state.selected_template,
                    template_settings
                )
                st.download_button(
                    label="💾 Download HTML",
                    data=html_data,
                    file_name=f"{st.session_state.resume_data['personal'].get('full_name', 'Resume')}_Resume.html",
                    mime="text/html",
                    use_container_width=True
                )
            except Exception as e:
                st.error(f"Error generating HTML: {str(e)}")
    
    # Job description analysis
    st.subheader("🎯 Job Description Analysis")
    st.markdown("Paste a job description to get tailored suggestions for your resume:")
    
    job_description = st.text_area(
        "Job Description",
        height=150,
        placeholder="Paste the job description here..."
    )
    
    if st.button("🔍 Analyze & Suggest Improvements") and job_description:
        ai_gen, _, _, _, _ = initialize_components()
        with st.spinner("Analyzing job description..."):
            suggestions = ai_gen.analyze_job_description(
                job_description,
                st.session_state.resume_data
            )
            
            st.markdown("### 💡 Suggestions:")
            for category, items in suggestions.items():
                if items:
                    st.markdown(f"**{category.replace('_', ' ').title()}:**")
                    for item in items:
                        st.markdown(f"• {item}")

def render_preview(template_mgr):
    """Render live preview of the resume"""
    try:
        preview_html = template_mgr.generate_preview(
            st.session_state.resume_data,
            st.session_state.selected_template
        )
        
        # Display preview in a markdown container
        st.markdown(preview_html, unsafe_allow_html=True)
        
    except Exception as e:
        st.error(f"Error generating preview: {str(e)}")
        st.markdown("Preview will appear here once you add some information.")

if __name__ == "__main__":
    main()
