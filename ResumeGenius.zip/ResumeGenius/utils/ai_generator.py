import os
import json
from openai import OpenAI
from typing import Dict, List, Any

class AIGenerator:
    def __init__(self):
        """Initialize AI Generator with OpenAI client"""
        self.client = OpenAI(
            api_key=os.getenv("OPENAI_API_KEY", "your-api-key-here")
        )
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        self.model = "gpt-4o"
    
    def generate_professional_summary(self, job_title: str, years_experience: int, 
                                    industry: str, resume_data: Dict) -> str:
        """Generate a professional summary based on user input"""
        try:
            # Extract relevant information from resume data
            skills = []
            if 'skills' in resume_data:
                for category, skill_list in resume_data['skills'].items():
                    skills.extend(skill_list)
            
            work_experience = resume_data.get('work_experience', [])
            education = resume_data.get('education', [])
            
            prompt = f"""
            Create a professional resume summary for a {job_title} position in the {industry} industry.
            
            Background Information:
            - Years of experience: {years_experience}
            - Skills: {', '.join(skills[:10]) if skills else 'Not specified'}
            - Previous roles: {', '.join([exp.get('job_title', '') for exp in work_experience[:3]])}
            - Education: {', '.join([edu.get('degree', '') for edu in education])}
            
            Requirements:
            - 3-4 sentences maximum
            - Highlight key strengths and achievements
            - Include relevant keywords for ATS optimization
            - Professional and compelling tone
            - Focus on value proposition
            
            Return only the summary text, no additional formatting.
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert resume writer specializing in creating compelling professional summaries."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=300,
                temperature=0.7
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            return f"Error generating summary: {str(e)}"
    
    def generate_job_bullets(self, job_title: str, job_description: str, company: str) -> List[str]:
        """Generate bullet points for work experience"""
        try:
            prompt = f"""
            Create 4-6 impactful bullet points for a {job_title} position at {company}.
            
            Job Description/Responsibilities:
            {job_description}
            
            Requirements:
            - Start each bullet with a strong action verb
            - Include quantifiable achievements where possible
            - Use keywords relevant to the role
            - Follow ATS-friendly formatting
            - Make them specific and results-oriented
            - Keep each bullet to 1-2 lines maximum
            
            Return the response as a JSON object with this format:
            {{"bullets": ["bullet point 1", "bullet point 2", ...]}}
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert resume writer specializing in creating impactful bullet points for work experience."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                max_tokens=500,
                temperature=0.7
            )
            
            result = json.loads(response.choices[0].message.content)
            return result.get("bullets", [])
            
        except Exception as e:
            return [f"Error generating bullet points: {str(e)}"]
    
    def suggest_skills(self, job_role: str) -> Dict[str, List[str]]:
        """Suggest relevant skills for a specific job role"""
        try:
            prompt = f"""
            Suggest relevant skills for a {job_role} position organized by category.
            
            Requirements:
            - Provide 5-8 skills per category
            - Include both technical and soft skills
            - Make suggestions current and industry-relevant
            - Organize into appropriate categories
            
            Return the response as a JSON object with this format:
            {{
                "Technical Skills": ["skill1", "skill2", ...],
                "Programming Languages": ["language1", "language2", ...],
                "Tools & Software": ["tool1", "tool2", ...],
                "Soft Skills": ["skill1", "skill2", ...]
            }}
            
            Adjust categories based on the job role relevance.
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert career advisor specializing in skill recommendations for different job roles."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                max_tokens=600,
                temperature=0.6
            )
            
            result = json.loads(response.choices[0].message.content)
            return result
            
        except Exception as e:
            return {"Error": [f"Error generating skills: {str(e)}"]}
    
    def analyze_job_description(self, job_description: str, resume_data: Dict) -> Dict[str, List[str]]:
        """Analyze job description and provide tailored suggestions"""
        try:
            # Extract current resume information
            current_skills = []
            if 'skills' in resume_data:
                for category, skill_list in resume_data['skills'].items():
                    current_skills.extend(skill_list)
            
            current_summary = resume_data.get('summary', '')
            work_experience = resume_data.get('work_experience', [])
            
            prompt = f"""
            Analyze this job description and provide specific suggestions to improve the resume match:
            
            Job Description:
            {job_description}
            
            Current Resume Information:
            - Summary: {current_summary}
            - Skills: {', '.join(current_skills)}
            - Recent Experience: {work_experience[0].get('job_title', 'Not specified') if work_experience else 'Not specified'}
            
            Provide suggestions in these categories:
            1. Missing keywords that should be added
            2. Skills to emphasize or add
            3. Summary improvements
            4. Experience bullet point suggestions
            
            Return the response as a JSON object with this format:
            {{
                "missing_keywords": ["keyword1", "keyword2", ...],
                "recommended_skills": ["skill1", "skill2", ...],
                "summary_improvements": ["improvement1", "improvement2", ...],
                "experience_suggestions": ["suggestion1", "suggestion2", ...]
            }}
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert ATS optimization specialist who helps improve resume match rates for specific job descriptions."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                max_tokens=800,
                temperature=0.6
            )
            
            result = json.loads(response.choices[0].message.content)
            return result
            
        except Exception as e:
            return {"error": [f"Error analyzing job description: {str(e)}"]}
    
    def optimize_for_ats(self, resume_data: Dict, job_title: str) -> Dict[str, Any]:
        """Optimize resume content for ATS systems"""
        try:
            prompt = f"""
            Optimize this resume content for ATS (Applicant Tracking System) for a {job_title} position.
            
            Current Resume Data:
            {json.dumps(resume_data, indent=2)}
            
            Provide ATS optimization suggestions including:
            1. Keyword optimization
            2. Format improvements
            3. Section recommendations
            4. Content structure suggestions
            
            Return the response as a JSON object with this format:
            {{
                "keyword_density_suggestions": ["suggestion1", "suggestion2", ...],
                "format_improvements": ["improvement1", "improvement2", ...],
                "section_recommendations": ["recommendation1", "recommendation2", ...],
                "ats_score": "score out of 10 with explanation"
            }}
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an ATS optimization expert who helps improve resume compatibility with applicant tracking systems."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                max_tokens=700,
                temperature=0.5
            )
            
            result = json.loads(response.choices[0].message.content)
            return result
            
        except Exception as e:
            return {"error": f"Error optimizing for ATS: {str(e)}"}
