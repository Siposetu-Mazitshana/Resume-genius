import json
import base64
from typing import Dict, Any, List
from datetime import datetime

class OfflineManager:
    """
    Manages offline functionality including data caching, 
    offline export capabilities, and local storage optimization
    """
    
    def __init__(self):
        self.cache_key = "tac_resume_cache"
        self.offline_templates = self._initialize_offline_templates()
    
    def _initialize_offline_templates(self) -> Dict[str, str]:
        """Initialize basic HTML templates for offline use"""
        return {
            'modern': self._get_modern_template(),
            'minimal': self._get_minimal_template(),
            'executive': self._get_executive_template()
        }
    
    def _get_modern_template(self) -> str:
        """Modern template HTML structure"""
        return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Resume - {name}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #2C3E50; }}
                .container {{ max-width: 800px; margin: 0 auto; background: white; padding: 40px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
                .header {{ text-align: center; border-bottom: 3px solid #2E86C1; padding-bottom: 20px; margin-bottom: 30px; }}
                .name {{ font-size: 24px; font-weight: bold; color: #2E86C1; margin-bottom: 10px; }}
                .contact {{ margin-bottom: 5px; }}
                .section {{ margin-bottom: 30px; }}
                .section-title {{ font-size: 16px; font-weight: bold; color: #2E86C1; text-transform: uppercase; letter-spacing: 1px; border-bottom: 2px solid #85C1E9; padding-bottom: 5px; margin-bottom: 15px; }}
                .job-header {{ display: flex; justify-content: space-between; margin-bottom: 5px; }}
                .job-title {{ font-weight: bold; color: #2E86C1; }}
                .company {{ font-weight: 600; }}
                .date-range {{ font-style: italic; color: #5D6D7E; font-size: 14px; }}
                .bullet {{ margin: 3px 0 3px 20px; position: relative; }}
                .bullet:before {{ content: "•"; color: #2E86C1; font-weight: bold; position: absolute; left: -15px; }}
                .skills {{ display: grid; gap: 8px; }}
                .skill-category {{ font-weight: 600; color: #2E86C1; }}
            </style>
        </head>
        <body>
            <div class="container">
                {content}
            </div>
        </body>
        </html>
        """
    
    def _get_minimal_template(self) -> str:
        """Minimal template HTML structure"""
        return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Resume - {name}</title>
            <style>
                body {{ font-family: Georgia, serif; margin: 0; padding: 20px; color: #333; line-height: 1.6; }}
                .container {{ max-width: 800px; margin: 0 auto; }}
                .header {{ text-align: center; margin-bottom: 30px; }}
                .name {{ font-size: 28px; font-weight: normal; margin-bottom: 10px; }}
                .contact {{ margin-bottom: 5px; }}
                .section {{ margin-bottom: 25px; }}
                .section-title {{ font-size: 14px; font-weight: bold; text-transform: uppercase; letter-spacing: 2px; border-bottom: 1px solid #ccc; padding-bottom: 3px; margin-bottom: 15px; }}
                .job-header {{ margin-bottom: 5px; }}
                .job-title {{ font-weight: bold; }}
                .company {{ font-style: italic; }}
                .date-range {{ color: #666; font-size: 14px; }}
                .bullet {{ margin: 2px 0 2px 15px; }}
                .skills {{ }}
                .skill-category {{ font-weight: bold; margin-bottom: 5px; }}
            </style>
        </head>
        <body>
            <div class="container">
                {content}
            </div>
        </body>
        </html>
        """
    
    def _get_executive_template(self) -> str:
        """Executive template HTML structure"""
        return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Resume - {name}</title>
            <style>
                body {{ font-family: 'Times New Roman', serif; margin: 0; padding: 20px; color: #2C3E50; }}
                .container {{ max-width: 800px; margin: 0 auto; background: white; padding: 40px; }}
                .header {{ text-align: center; margin-bottom: 40px; }}
                .name {{ font-size: 26px; font-weight: bold; margin-bottom: 15px; }}
                .contact {{ margin-bottom: 8px; font-size: 14px; }}
                .section {{ margin-bottom: 35px; }}
                .section-title {{ font-size: 18px; font-weight: bold; color: #34495E; border-bottom: 2px solid #34495E; padding-bottom: 8px; margin-bottom: 20px; }}
                .job-header {{ margin-bottom: 8px; }}
                .job-title {{ font-size: 16px; font-weight: bold; }}
                .company {{ font-size: 15px; font-weight: 600; color: #5D6D7E; }}
                .date-range {{ font-style: italic; color: #7F8C8D; }}
                .bullet {{ margin: 5px 0 5px 20px; }}
                .skills {{ line-height: 1.8; }}
                .skill-category {{ font-weight: bold; color: #34495E; }}
            </style>
        </head>
        <body>
            <div class="container">
                {content}
            </div>
        </body>
        </html>
        """
    
    def generate_offline_html(self, resume_data: Dict[str, Any], template_name: str = 'modern') -> str:
        """Generate standalone HTML resume that works completely offline"""
        
        template = self.offline_templates.get(template_name, self.offline_templates['modern'])
        
        # Build content sections
        content_parts = []
        
        # Header section
        personal = resume_data.get('personal', {})
        if personal.get('full_name'):
            header_content = f'<div class="header">'
            header_content += f'<div class="name">{personal["full_name"]}</div>'
            
            contact_info = []
            if personal.get('email'):
                contact_info.append(personal['email'])
            if personal.get('phone'):
                contact_info.append(personal['phone'])
            if personal.get('location'):
                contact_info.append(personal['location'])
            
            if contact_info:
                header_content += f'<div class="contact">{" • ".join(contact_info)}</div>'
            
            if personal.get('linkedin') or personal.get('website'):
                links = []
                if personal.get('linkedin'):
                    links.append(f'LinkedIn: {personal["linkedin"]}')
                if personal.get('website'):
                    links.append(f'Website: {personal["website"]}')
                header_content += f'<div class="contact">{" • ".join(links)}</div>'
            
            header_content += '</div>'
            content_parts.append(header_content)
        
        # Professional Summary
        if resume_data.get('summary'):
            summary_content = f'''
            <div class="section">
                <div class="section-title">Professional Summary</div>
                <p>{resume_data["summary"]}</p>
            </div>
            '''
            content_parts.append(summary_content)
        
        # Work Experience
        work_exp = resume_data.get('work_experience', [])
        if work_exp:
            exp_content = '<div class="section"><div class="section-title">Professional Experience</div>'
            
            for exp in work_exp:
                exp_content += f'''
                <div style="margin-bottom: 20px;">
                    <div class="job-header">
                        <div>
                            <span class="job-title">{exp.get("job_title", "")}</span>
                            <span class="company"> - {exp.get("company", "")}</span>
                        </div>
                        <div class="date-range">
                            {exp.get("start_date", "")} to {exp.get("end_date", "Present")}
                            {" • " + exp.get("location", "") if exp.get("location") else ""}
                        </div>
                    </div>
                '''
                
                if exp.get('bullets'):
                    for bullet in exp['bullets']:
                        exp_content += f'<div class="bullet">{bullet}</div>'
                
                exp_content += '</div>'
            
            exp_content += '</div>'
            content_parts.append(exp_content)
        
        # Education
        education = resume_data.get('education', [])
        if education:
            edu_content = '<div class="section"><div class="section-title">Education</div>'
            
            for edu in education:
                edu_content += f'''
                <div style="margin-bottom: 15px;">
                    <div class="job-title">{edu.get("degree", "")}
                '''
                
                if edu.get('major'):
                    edu_content += f' in {edu["major"]}'
                
                edu_content += f' - {edu.get("school", "")}</div>'
                
                details = []
                if edu.get('graduation_date'):
                    details.append(edu['graduation_date'])
                if edu.get('gpa'):
                    details.append(f"GPA: {edu['gpa']}")
                if edu.get('honors'):
                    details.append(edu['honors'])
                
                if details:
                    edu_content += f'<div class="date-range">{" • ".join(details)}</div>'
                
                edu_content += '</div>'
            
            edu_content += '</div>'
            content_parts.append(edu_content)
        
        # Skills
        skills = resume_data.get('skills', {})
        if skills:
            skills_content = '<div class="section"><div class="section-title">Skills</div><div class="skills">'
            
            for category, skill_list in skills.items():
                if skill_list:
                    skills_content += f'''
                    <div style="margin-bottom: 10px;">
                        <span class="skill-category">{category}:</span> {", ".join(skill_list)}
                    </div>
                    '''
            
            skills_content += '</div></div>'
            content_parts.append(skills_content)
        
        # Projects
        projects = resume_data.get('projects', [])
        if projects:
            proj_content = '<div class="section"><div class="section-title">Projects</div>'
            
            for project in projects:
                proj_content += f'''
                <div style="margin-bottom: 15px;">
                    <div class="job-title">{project.get("name", "")}
                '''
                
                if project.get('technologies'):
                    proj_content += f' ({project["technologies"]})'
                
                proj_content += '</div>'
                
                if project.get('description'):
                    proj_content += f'<div>{project["description"]}</div>'
                
                if project.get('url'):
                    proj_content += f'<div class="date-range">URL: {project["url"]}</div>'
                
                proj_content += '</div>'
            
            proj_content += '</div>'
            content_parts.append(proj_content)
        
        # Certifications
        certifications = resume_data.get('certifications', [])
        if certifications:
            cert_content = '<div class="section"><div class="section-title">Certifications</div>'
            
            for cert in certifications:
                cert_content += f'''
                <div style="margin-bottom: 10px;">
                    <div class="job-title">{cert.get("name", "")} - {cert.get("issuer", "")}</div>
                '''
                
                if cert.get('date'):
                    cert_content += f'<div class="date-range">{cert["date"]}</div>'
                
                if cert.get('id'):
                    cert_content += f'<div class="date-range">ID: {cert["id"]}</div>'
                
                cert_content += '</div>'
            
            cert_content += '</div>'
            content_parts.append(cert_content)
        
        # Combine all content
        full_content = '\n'.join(content_parts)
        
        # Insert content into template
        final_html = template.format(
            name=personal.get('full_name', 'Resume'),
            content=full_content
        )
        
        return final_html
    
    def create_offline_package(self, resume_data: Dict[str, Any]) -> Dict[str, str]:
        """Create a complete offline package with multiple formats"""
        
        package = {}
        
        # Generate HTML versions for all templates
        for template_name in self.offline_templates.keys():
            html_content = self.generate_offline_html(resume_data, template_name)
            package[f'{template_name}_resume.html'] = html_content
        
        # Create a simple CSS file for customization
        package['custom_styles.css'] = self._get_custom_css()
        
        # Create a README file
        package['README.txt'] = self._get_readme_content()
        
        return package
    
    def _get_custom_css(self) -> str:
        """Generate custom CSS file for offline customization"""
        return """
/* Custom Resume Styles - Edit these to customize your resume appearance */

/* Color Schemes - Uncomment one to use */

/* Blue Theme (Default) */
:root {
    --primary-color: #2E86C1;
    --secondary-color: #85C1E9;
    --accent-color: #1B4F72;
    --text-color: #2C3E50;
}

/* Green Theme 
:root {
    --primary-color: #27AE60;
    --secondary-color: #82E5AA;
    --accent-color: #196F3D;
    --text-color: #2C3E50;
}
*/

/* Purple Theme 
:root {
    --primary-color: #8E44AD;
    --secondary-color: #C39BD3;
    --accent-color: #633974;
    --text-color: #2C3E50;
}
*/

/* Red Theme 
:root {
    --primary-color: #E74C3C;
    --secondary-color: #F1948A;
    --accent-color: #A93226;
    --text-color: #2C3E50;
}
*/

/* Apply color scheme to templates */
.name, .section-title, .job-title, .skill-category {
    color: var(--primary-color) !important;
}

.bullet:before {
    color: var(--primary-color) !important;
}

/* Font customization */
body {
    font-size: 12px; /* Adjust base font size */
    line-height: 1.5; /* Adjust line spacing */
}

/* Print optimization */
@media print {
    body { margin: 0; padding: 10px; }
    .container { box-shadow: none; padding: 20px; }
    .section { page-break-inside: avoid; }
}
        """
    
    def _get_readme_content(self) -> str:
        """Generate README file for offline package"""
        return """
TAC Resume Builder - Offline Package
===================================

This package contains your resume in multiple formats for offline use.

Files included:
- modern_resume.html     - Modern professional template
- minimal_resume.html    - Clean minimal template  
- executive_resume.html  - Executive style template
- custom_styles.css      - Customization options
- README.txt            - This file

Usage Instructions:
1. Open any .html file in your web browser to view your resume
2. Use Ctrl+P (Cmd+P on Mac) to print or save as PDF
3. Edit custom_styles.css to change colors and fonts
4. All files work completely offline - no internet required

Customization:
- Edit custom_styles.css to change color schemes
- Uncomment different color themes in the CSS file
- Adjust font sizes and spacing as needed
- Templates are fully self-contained HTML files

Browser Compatibility:
- Works in all modern web browsers
- Chrome, Firefox, Safari, Edge supported
- Mobile browsers supported for viewing

For best results when printing to PDF:
- Use Chrome or Edge browser
- Set margins to minimum
- Enable background graphics
- Use A4 or Letter paper size

Generated by TAC Resume Builder
For more templates and features, visit the web application.
        """
    
    def get_offline_stats(self, resume_data: Dict[str, Any]) -> Dict[str, Any]:
        """Get statistics about offline capabilities"""
        
        stats = {
            'offline_ready': True,
            'templates_available': len(self.offline_templates),
            'export_formats': ['HTML', 'Print to PDF'],
            'file_size_estimate': '< 100KB per template',
            'browser_compatibility': ['Chrome', 'Firefox', 'Safari', 'Edge'],
            'features_offline': [
                'Resume viewing',
                'Print to PDF', 
                'Color customization',
                'Font adjustment',
                'Mobile responsive'
            ],
            'features_require_internet': [
                'AI content generation',
                'Advanced PDF export',
                'DOCX export'
            ]
        }
        
        return stats