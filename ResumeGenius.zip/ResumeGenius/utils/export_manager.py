import io
import os
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.shared import OxmlElement, qn
from typing import Dict, Any
import json

class ExportManager:
    def __init__(self):
        """Initialize Export Manager"""
        self.color_schemes = {
            'Blue': {'primary': '#2E86C1', 'secondary': '#85C1E9', 'text': '#2C3E50'},
            'Green': {'primary': '#27AE60', 'secondary': '#82E5AA', 'text': '#2C3E50'},
            'Purple': {'primary': '#8E44AD', 'secondary': '#C39BD3', 'text': '#2C3E50'},
            'Red': {'primary': '#E74C3C', 'secondary': '#F1948A', 'text': '#2C3E50'},
            'Orange': {'primary': '#E67E22', 'secondary': '#F8C471', 'text': '#2C3E50'},
            'Teal': {'primary': '#16A085', 'secondary': '#7FB3D3', 'text': '#2C3E50'},
            'Gray': {'primary': '#5D6D7E', 'secondary': '#BDC3C7', 'text': '#2C3E50'}
        }
    
    def export_to_pdf(self, resume_data: Dict, template_name: str, settings: Dict) -> bytes:
        """Export resume to PDF format"""
        try:
            buffer = io.BytesIO()
            doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=0.75*inch, 
                                  leftMargin=0.75*inch, topMargin=0.75*inch, bottomMargin=0.75*inch)
            
            # Get styles
            styles = getSampleStyleSheet()
            colors_scheme = self.color_schemes.get(settings.get('color_scheme', 'Blue'))
            
            # Custom styles
            title_style = ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontSize=18,
                textColor=colors.HexColor(colors_scheme['primary']),
                alignment=TA_CENTER,
                spaceAfter=6
            )
            
            heading_style = ParagraphStyle(
                'CustomHeading',
                parent=styles['Heading2'],
                fontSize=14,
                textColor=colors.HexColor(colors_scheme['primary']),
                borderWidth=1,
                borderColor=colors.HexColor(colors_scheme['secondary']),
                borderPadding=5,
                spaceAfter=6
            )
            
            body_style = ParagraphStyle(
                'CustomBody',
                parent=styles['Normal'],
                fontSize=10,
                textColor=colors.HexColor(colors_scheme['text']),
                spaceAfter=4
            )
            
            # Build PDF content
            story = []
            
            # Header - Personal Information
            personal = resume_data.get('personal', {})
            if personal.get('full_name'):
                story.append(Paragraph(personal['full_name'], title_style))
                
                contact_info = []
                if personal.get('email'):
                    contact_info.append(personal['email'])
                if personal.get('phone'):
                    contact_info.append(personal['phone'])
                if personal.get('location'):
                    contact_info.append(personal['location'])
                
                if contact_info:
                    story.append(Paragraph(' • '.join(contact_info), body_style))
                
                if personal.get('linkedin') or personal.get('website'):
                    links = []
                    if personal.get('linkedin'):
                        links.append(f"LinkedIn: {personal['linkedin']}")
                    if personal.get('website'):
                        links.append(f"Website: {personal['website']}")
                    story.append(Paragraph(' • '.join(links), body_style))
                
                story.append(Spacer(1, 12))
            
            # Professional Summary
            if resume_data.get('summary'):
                story.append(Paragraph("PROFESSIONAL SUMMARY", heading_style))
                story.append(Paragraph(resume_data['summary'], body_style))
                story.append(Spacer(1, 12))
            
            # Work Experience
            work_exp = resume_data.get('work_experience', [])
            if work_exp:
                story.append(Paragraph("PROFESSIONAL EXPERIENCE", heading_style))
                
                for exp in work_exp:
                    # Job title and company
                    job_header = f"<b>{exp.get('job_title', '')}</b> - {exp.get('company', '')}"
                    if exp.get('location'):
                        job_header += f" ({exp['location']})"
                    story.append(Paragraph(job_header, body_style))
                    
                    # Dates
                    date_range = f"{exp.get('start_date', '')} to {exp.get('end_date', 'Present')}"
                    story.append(Paragraph(f"<i>{date_range}</i>", body_style))
                    
                    # Bullet points
                    if exp.get('bullets'):
                        for bullet in exp['bullets']:
                            story.append(Paragraph(f"• {bullet}", body_style))
                    
                    story.append(Spacer(1, 8))
            
            # Education
            education = resume_data.get('education', [])
            if education:
                story.append(Paragraph("EDUCATION", heading_style))
                
                for edu in education:
                    edu_text = f"<b>{edu.get('degree', '')}</b>"
                    if edu.get('major'):
                        edu_text += f" in {edu['major']}"
                    edu_text += f" - {edu.get('school', '')}"
                    if edu.get('graduation_date'):
                        edu_text += f" ({edu['graduation_date']})"
                    
                    story.append(Paragraph(edu_text, body_style))
                    
                    if edu.get('gpa'):
                        story.append(Paragraph(f"GPA: {edu['gpa']}", body_style))
                    if edu.get('honors'):
                        story.append(Paragraph(f"Honors: {edu['honors']}", body_style))
                    
                    story.append(Spacer(1, 4))
            
            # Skills
            skills = resume_data.get('skills', {})
            if skills:
                story.append(Paragraph("SKILLS", heading_style))
                
                for category, skill_list in skills.items():
                    if skill_list:
                        skills_text = f"<b>{category}:</b> {', '.join(skill_list)}"
                        story.append(Paragraph(skills_text, body_style))
                
                story.append(Spacer(1, 12))
            
            # Projects
            projects = resume_data.get('projects', [])
            if projects:
                story.append(Paragraph("PROJECTS", heading_style))
                
                for project in projects:
                    project_header = f"<b>{project.get('name', '')}</b>"
                    if project.get('technologies'):
                        project_header += f" ({project['technologies']})"
                    story.append(Paragraph(project_header, body_style))
                    
                    if project.get('description'):
                        story.append(Paragraph(project['description'], body_style))
                    
                    if project.get('url'):
                        story.append(Paragraph(f"URL: {project['url']}", body_style))
                    
                    story.append(Spacer(1, 4))
            
            # Certifications
            certifications = resume_data.get('certifications', [])
            if certifications:
                story.append(Paragraph("CERTIFICATIONS", heading_style))
                
                for cert in certifications:
                    cert_text = f"<b>{cert.get('name', '')}</b> - {cert.get('issuer', '')}"
                    if cert.get('date'):
                        cert_text += f" ({cert['date']})"
                    story.append(Paragraph(cert_text, body_style))
                    
                    if cert.get('id'):
                        story.append(Paragraph(f"ID: {cert['id']}", body_style))
            
            # Build PDF
            doc.build(story)
            buffer.seek(0)
            return buffer.getvalue()
            
        except Exception as e:
            raise Exception(f"PDF export failed: {str(e)}")
    
    def export_to_docx(self, resume_data: Dict, template_name: str, settings: Dict) -> bytes:
        """Export resume to DOCX format"""
        try:
            doc = Document()
            
            # Set document margins
            sections = doc.sections
            for section in sections:
                section.top_margin = Inches(0.5)
                section.bottom_margin = Inches(0.5)
                section.left_margin = Inches(0.75)
                section.right_margin = Inches(0.75)
            
            # Header - Personal Information
            personal = resume_data.get('personal', {})
            if personal.get('full_name'):
                # Name
                name_para = doc.add_paragraph()
                name_run = name_para.add_run(personal['full_name'])
                name_run.font.size = Pt(18)
                name_run.bold = True
                name_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                
                # Contact info
                contact_info = []
                if personal.get('email'):
                    contact_info.append(personal['email'])
                if personal.get('phone'):
                    contact_info.append(personal['phone'])
                if personal.get('location'):
                    contact_info.append(personal['location'])
                
                if contact_info:
                    contact_para = doc.add_paragraph(' • '.join(contact_info))
                    contact_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                
                # Links
                if personal.get('linkedin') or personal.get('website'):
                    links = []
                    if personal.get('linkedin'):
                        links.append(f"LinkedIn: {personal['linkedin']}")
                    if personal.get('website'):
                        links.append(f"Website: {personal['website']}")
                    link_para = doc.add_paragraph(' • '.join(links))
                    link_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                
                doc.add_paragraph()  # Add space
            
            # Professional Summary
            if resume_data.get('summary'):
                self._add_section_heading(doc, "PROFESSIONAL SUMMARY")
                doc.add_paragraph(resume_data['summary'])
            
            # Work Experience
            work_exp = resume_data.get('work_experience', [])
            if work_exp:
                self._add_section_heading(doc, "PROFESSIONAL EXPERIENCE")
                
                for exp in work_exp:
                    # Job title and company
                    job_para = doc.add_paragraph()
                    job_run = job_para.add_run(f"{exp.get('job_title', '')} - {exp.get('company', '')}")
                    job_run.bold = True
                    
                    if exp.get('location'):
                        location_run = job_para.add_run(f" ({exp['location']})")
                    
                    # Dates
                    date_range = f"{exp.get('start_date', '')} to {exp.get('end_date', 'Present')}"
                    date_para = doc.add_paragraph(date_range)
                    date_para.style = 'Italic'
                    
                    # Bullet points
                    if exp.get('bullets'):
                        for bullet in exp['bullets']:
                            bullet_para = doc.add_paragraph(bullet, style='List Bullet')
                    
                    doc.add_paragraph()  # Add space between jobs
            
            # Education
            education = resume_data.get('education', [])
            if education:
                self._add_section_heading(doc, "EDUCATION")
                
                for edu in education:
                    edu_para = doc.add_paragraph()
                    degree_run = edu_para.add_run(edu.get('degree', ''))
                    degree_run.bold = True
                    
                    if edu.get('major'):
                        edu_para.add_run(f" in {edu['major']}")
                    
                    edu_para.add_run(f" - {edu.get('school', '')}")
                    
                    if edu.get('graduation_date'):
                        edu_para.add_run(f" ({edu['graduation_date']})")
                    
                    if edu.get('gpa'):
                        doc.add_paragraph(f"GPA: {edu['gpa']}")
                    if edu.get('honors'):
                        doc.add_paragraph(f"Honors: {edu['honors']}")
            
            # Skills
            skills = resume_data.get('skills', {})
            if skills:
                self._add_section_heading(doc, "SKILLS")
                
                for category, skill_list in skills.items():
                    if skill_list:
                        skill_para = doc.add_paragraph()
                        category_run = skill_para.add_run(f"{category}: ")
                        category_run.bold = True
                        skill_para.add_run(', '.join(skill_list))
            
            # Projects
            projects = resume_data.get('projects', [])
            if projects:
                self._add_section_heading(doc, "PROJECTS")
                
                for project in projects:
                    project_para = doc.add_paragraph()
                    name_run = project_para.add_run(project.get('name', ''))
                    name_run.bold = True
                    
                    if project.get('technologies'):
                        project_para.add_run(f" ({project['technologies']})")
                    
                    if project.get('description'):
                        doc.add_paragraph(project['description'])
                    
                    if project.get('url'):
                        doc.add_paragraph(f"URL: {project['url']}")
            
            # Certifications
            certifications = resume_data.get('certifications', [])
            if certifications:
                self._add_section_heading(doc, "CERTIFICATIONS")
                
                for cert in certifications:
                    cert_para = doc.add_paragraph()
                    name_run = cert_para.add_run(cert.get('name', ''))
                    name_run.bold = True
                    cert_para.add_run(f" - {cert.get('issuer', '')}")
                    
                    if cert.get('date'):
                        cert_para.add_run(f" ({cert['date']})")
                    
                    if cert.get('id'):
                        doc.add_paragraph(f"ID: {cert['id']}")
            
            # Save to buffer
            buffer = io.BytesIO()
            doc.save(buffer)
            buffer.seek(0)
            return buffer.getvalue()
            
        except Exception as e:
            raise Exception(f"DOCX export failed: {str(e)}")
    
    def export_to_html(self, resume_data: Dict, template_name: str, settings: Dict) -> str:
        """Export resume to HTML format"""
        try:
            colors_scheme = self.color_schemes.get(settings.get('color_scheme', 'Blue'))
            
            html_content = f"""
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>{resume_data.get('personal', {}).get('full_name', 'Resume')}</title>
                <style>
                    body {{
                        font-family: {settings.get('font_family', 'Arial')}, sans-serif;
                        line-height: 1.6;
                        color: {colors_scheme['text']};
                        max-width: 800px;
                        margin: 0 auto;
                        padding: 20px;
                        background-color: #ffffff;
                    }}
                    
                    .header {{
                        text-align: center;
                        border-bottom: 3px solid {colors_scheme['primary']};
                        padding-bottom: 20px;
                        margin-bottom: 30px;
                    }}
                    
                    .name {{
                        font-size: 2.5em;
                        font-weight: bold;
                        color: {colors_scheme['primary']};
                        margin-bottom: 10px;
                    }}
                    
                    .contact-info {{
                        font-size: 1.1em;
                        margin-bottom: 5px;
                    }}
                    
                    .section {{
                        margin-bottom: 30px;
                    }}
                    
                    .section-title {{
                        font-size: 1.4em;
                        font-weight: bold;
                        color: {colors_scheme['primary']};
                        border-bottom: 2px solid {colors_scheme['secondary']};
                        padding-bottom: 5px;
                        margin-bottom: 15px;
                        text-transform: uppercase;
                    }}
                    
                    .job-title {{
                        font-weight: bold;
                        font-size: 1.1em;
                        color: {colors_scheme['primary']};
                    }}
                    
                    .company {{
                        font-weight: bold;
                    }}
                    
                    .date-range {{
                        font-style: italic;
                        color: #666;
                        margin-bottom: 5px;
                    }}
                    
                    .bullet-point {{
                        margin-left: 20px;
                        margin-bottom: 3px;
                    }}
                    
                    .bullet-point:before {{
                        content: "• ";
                        color: {colors_scheme['primary']};
                        font-weight: bold;
                    }}
                    
                    .skill-category {{
                        margin-bottom: 8px;
                    }}
                    
                    .skill-category strong {{
                        color: {colors_scheme['primary']};
                    }}
                    
                    .project-name {{
                        font-weight: bold;
                        color: {colors_scheme['primary']};
                    }}
                    
                    .cert-name {{
                        font-weight: bold;
                        color: {colors_scheme['primary']};
                    }}
                    
                    @media print {{
                        body {{
                            margin: 0;
                            padding: 10px;
                        }}
                        .section {{
                            page-break-inside: avoid;
                        }}
                    }}
                </style>
            </head>
            <body>
            """
            
            # Header
            personal = resume_data.get('personal', {})
            if personal.get('full_name'):
                html_content += f"""
                <div class="header">
                    <div class="name">{personal['full_name']}</div>
                """
                
                contact_info = []
                if personal.get('email'):
                    contact_info.append(personal['email'])
                if personal.get('phone'):
                    contact_info.append(personal['phone'])
                if personal.get('location'):
                    contact_info.append(personal['location'])
                
                if contact_info:
                    html_content += f'<div class="contact-info">{" • ".join(contact_info)}</div>'
                
                if personal.get('linkedin') or personal.get('website'):
                    links = []
                    if personal.get('linkedin'):
                        links.append(f'<a href="{personal["linkedin"]}" target="_blank">LinkedIn</a>')
                    if personal.get('website'):
                        links.append(f'<a href="{personal["website"]}" target="_blank">Website</a>')
                    html_content += f'<div class="contact-info">{" • ".join(links)}</div>'
                
                html_content += "</div>"
            
            # Professional Summary
            if resume_data.get('summary'):
                html_content += f"""
                <div class="section">
                    <div class="section-title">Professional Summary</div>
                    <p>{resume_data['summary']}</p>
                </div>
                """
            
            # Work Experience
            work_exp = resume_data.get('work_experience', [])
            if work_exp:
                html_content += """
                <div class="section">
                    <div class="section-title">Professional Experience</div>
                """
                
                for exp in work_exp:
                    html_content += f"""
                    <div style="margin-bottom: 20px;">
                        <div class="job-title">{exp.get('job_title', '')} - <span class="company">{exp.get('company', '')}</span>
                    """
                    
                    if exp.get('location'):
                        html_content += f" ({exp['location']})"
                    
                    html_content += "</div>"
                    
                    date_range = f"{exp.get('start_date', '')} to {exp.get('end_date', 'Present')}"
                    html_content += f'<div class="date-range">{date_range}</div>'
                    
                    if exp.get('bullets'):
                        for bullet in exp['bullets']:
                            html_content += f'<div class="bullet-point">{bullet}</div>'
                    
                    html_content += "</div>"
                
                html_content += "</div>"
            
            # Education
            education = resume_data.get('education', [])
            if education:
                html_content += """
                <div class="section">
                    <div class="section-title">Education</div>
                """
                
                for edu in education:
                    html_content += f"""
                    <div style="margin-bottom: 15px;">
                        <div><strong>{edu.get('degree', '')}</strong>
                    """
                    
                    if edu.get('major'):
                        html_content += f" in {edu['major']}"
                    
                    html_content += f" - {edu.get('school', '')}"
                    
                    if edu.get('graduation_date'):
                        html_content += f" ({edu['graduation_date']})"
                    
                    html_content += "</div>"
                    
                    if edu.get('gpa'):
                        html_content += f"<div>GPA: {edu['gpa']}</div>"
                    if edu.get('honors'):
                        html_content += f"<div>Honors: {edu['honors']}</div>"
                    
                    html_content += "</div>"
                
                html_content += "</div>"
            
            # Skills
            skills = resume_data.get('skills', {})
            if skills:
                html_content += """
                <div class="section">
                    <div class="section-title">Skills</div>
                """
                
                for category, skill_list in skills.items():
                    if skill_list:
                        html_content += f"""
                        <div class="skill-category">
                            <strong>{category}:</strong> {', '.join(skill_list)}
                        </div>
                        """
                
                html_content += "</div>"
            
            # Projects
            projects = resume_data.get('projects', [])
            if projects:
                html_content += """
                <div class="section">
                    <div class="section-title">Projects</div>
                """
                
                for project in projects:
                    html_content += f"""
                    <div style="margin-bottom: 15px;">
                        <div class="project-name">{project.get('name', '')}
                    """
                    
                    if project.get('technologies'):
                        html_content += f" ({project['technologies']})"
                    
                    html_content += "</div>"
                    
                    if project.get('description'):
                        html_content += f"<div>{project['description']}</div>"
                    
                    if project.get('url'):
                        html_content += f'<div>URL: <a href="{project["url"]}" target="_blank">{project["url"]}</a></div>'
                    
                    html_content += "</div>"
                
                html_content += "</div>"
            
            # Certifications
            certifications = resume_data.get('certifications', [])
            if certifications:
                html_content += """
                <div class="section">
                    <div class="section-title">Certifications</div>
                """
                
                for cert in certifications:
                    html_content += f"""
                    <div style="margin-bottom: 10px;">
                        <div class="cert-name">{cert.get('name', '')} - {cert.get('issuer', '')}
                    """
                    
                    if cert.get('date'):
                        html_content += f" ({cert['date']})"
                    
                    html_content += "</div>"
                    
                    if cert.get('id'):
                        html_content += f"<div>ID: {cert['id']}</div>"
                    
                    html_content += "</div>"
                
                html_content += "</div>"
            
            html_content += """
            </body>
            </html>
            """
            
            return html_content
            
        except Exception as e:
            raise Exception(f"HTML export failed: {str(e)}")
    
    def _add_section_heading(self, doc, title):
        """Add a section heading to DOCX document"""
        heading = doc.add_paragraph()
        heading_run = heading.add_run(title)
        heading_run.font.size = Pt(14)
        heading_run.bold = True
        heading.space_after = Pt(6)
        
        # Add border below heading
        p = heading._element
        pPr = p.get_or_add_pPr()
        pBdr = OxmlElement('w:pBdr')
        pPr.insert_element_before(pBdr, 'w:shd', 'w:tabs', 'w:suppressAutoHyphens', 'w:kinsoku', 'w:wordWrap',
                                  'w:overflowPunct', 'w:topLinePunct', 'w:autoSpaceDE', 'w:autoSpaceDN',
                                  'w:bidi', 'w:adjustRightInd', 'w:snapToGrid', 'w:spacing', 'w:ind',
                                  'w:contextualSpacing', 'w:mirrorIndents', 'w:suppressOverlap', 'w:jc',
                                  'w:textDirection', 'w:textAlignment', 'w:textboxTightWrap',
                                  'w:outlineLvl', 'w:divId', 'w:cnfStyle', 'w:rPr', 'w:sectPr',
                                  'w:sectPrChange')
        bottom = OxmlElement('w:bottom')
        bottom.set(qn('w:val'), 'single')
        bottom.set(qn('w:sz'), '6')
        bottom.set(qn('w:space'), '1')
        bottom.set(qn('w:color'), 'auto')
        pBdr.append(bottom)
