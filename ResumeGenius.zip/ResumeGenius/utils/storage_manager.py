import json
import os
from typing import Dict, Any
import streamlit as st

class StorageManager:
    def __init__(self):
        """Initialize Storage Manager"""
        self.storage_file = "resume_data.json"
        self.session_key = "tac_resume_data"
    
    def get_empty_resume_data(self) -> Dict[str, Any]:
        """Get empty resume data structure"""
        return {
            'personal': {
                'full_name': '',
                'email': '',
                'phone': '',
                'location': '',
                'linkedin': '',
                'website': ''
            },
            'summary': '',
            'work_experience': [],
            'education': [],
            'skills': {},
            'projects': [],
            'certifications': [],
            'created_at': '',
            'updated_at': ''
        }
    
    def save_resume_data(self, resume_data: Dict[str, Any]) -> bool:
        """Save resume data to local storage"""
        try:
            # Update timestamp
            from datetime import datetime
            resume_data['updated_at'] = datetime.now().isoformat()
            
            if not resume_data.get('created_at'):
                resume_data['created_at'] = resume_data['updated_at']
            
            # Save to session state
            st.session_state[self.session_key] = resume_data
            
            # Also save to file if possible (for persistence)
            try:
                with open(self.storage_file, 'w', encoding='utf-8') as f:
                    json.dump(resume_data, f, indent=2, ensure_ascii=False)
            except Exception:
                # File saving might fail in some environments, but session state should work
                pass
            
            return True
            
        except Exception as e:
            st.error(f"Error saving resume data: {str(e)}")
            return False
    
    def load_resume_data(self) -> Dict[str, Any]:
        """Load resume data from local storage"""
        try:
            # First try to load from session state
            if self.session_key in st.session_state:
                return st.session_state[self.session_key]
            
            # Then try to load from file
            if os.path.exists(self.storage_file):
                try:
                    with open(self.storage_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        # Store in session state for future use
                        st.session_state[self.session_key] = data
                        return data
                except Exception:
                    pass
            
            # Return empty data if nothing found
            empty_data = self.get_empty_resume_data()
            st.session_state[self.session_key] = empty_data
            return empty_data
            
        except Exception as e:
            st.error(f"Error loading resume data: {str(e)}")
            return self.get_empty_resume_data()
    
    def clear_resume_data(self) -> bool:
        """Clear all resume data"""
        try:
            # Clear session state
            if self.session_key in st.session_state:
                del st.session_state[self.session_key]
            
            # Clear file if it exists
            if os.path.exists(self.storage_file):
                try:
                    os.remove(self.storage_file)
                except Exception:
                    pass
            
            return True
            
        except Exception as e:
            st.error(f"Error clearing resume data: {str(e)}")
            return False
    
    def export_resume_data(self) -> str:
        """Export resume data as JSON string for backup"""
        try:
            resume_data = self.load_resume_data()
            return json.dumps(resume_data, indent=2, ensure_ascii=False)
        except Exception as e:
            st.error(f"Error exporting resume data: {str(e)}")
            return "{}"
    
    def import_resume_data(self, json_data: str) -> bool:
        """Import resume data from JSON string"""
        try:
            resume_data = json.loads(json_data)
            
            # Validate the structure
            if not self._validate_resume_structure(resume_data):
                st.error("Invalid resume data structure")
                return False
            
            # Save the imported data
            return self.save_resume_data(resume_data)
            
        except json.JSONDecodeError:
            st.error("Invalid JSON format")
            return False
        except Exception as e:
            st.error(f"Error importing resume data: {str(e)}")
            return False
    
    def _validate_resume_structure(self, data: Dict) -> bool:
        """Validate that the resume data has the expected structure"""
        try:
            required_keys = ['personal', 'summary', 'work_experience', 'education', 'skills']
            
            for key in required_keys:
                if key not in data:
                    return False
            
            # Validate personal section
            if not isinstance(data['personal'], dict):
                return False
            
            # Validate lists
            list_sections = ['work_experience', 'education', 'projects', 'certifications']
            for section in list_sections:
                if section in data and not isinstance(data[section], list):
                    return False
            
            # Validate skills section
            if not isinstance(data['skills'], dict):
                return False
            
            return True
            
        except Exception:
            return False
    
    def get_resume_statistics(self) -> Dict[str, Any]:
        """Get statistics about the current resume"""
        try:
            resume_data = self.load_resume_data()
            
            stats = {
                'completion_percentage': 0,
                'sections_completed': 0,
                'total_sections': 7,
                'word_count': 0,
                'last_updated': resume_data.get('updated_at', 'Never'),
                'sections_status': {}
            }
            
            # Check section completion
            sections = {
                'Personal Information': bool(resume_data['personal'].get('full_name') and 
                                           resume_data['personal'].get('email')),
                'Professional Summary': bool(resume_data.get('summary')),
                'Work Experience': len(resume_data.get('work_experience', [])) > 0,
                'Education': len(resume_data.get('education', [])) > 0,
                'Skills': len(resume_data.get('skills', {})) > 0,
                'Projects': len(resume_data.get('projects', [])) > 0,
                'Certifications': len(resume_data.get('certifications', [])) > 0
            }
            
            stats['sections_status'] = sections
            stats['sections_completed'] = sum(sections.values())
            stats['completion_percentage'] = (stats['sections_completed'] / stats['total_sections']) * 100
            
            # Calculate word count
            text_content = []
            if resume_data.get('summary'):
                text_content.append(resume_data['summary'])
            
            for exp in resume_data.get('work_experience', []):
                if exp.get('bullets'):
                    text_content.extend(exp['bullets'])
            
            for project in resume_data.get('projects', []):
                if project.get('description'):
                    text_content.append(project['description'])
            
            stats['word_count'] = sum(len(text.split()) for text in text_content)
            
            return stats
            
        except Exception as e:
            st.error(f"Error calculating resume statistics: {str(e)}")
            return {
                'completion_percentage': 0,
                'sections_completed': 0,
                'total_sections': 7,
                'word_count': 0,
                'last_updated': 'Error',
                'sections_status': {}
            }
    
    def create_backup(self) -> str:
        """Create a backup of current resume data"""
        try:
            from datetime import datetime
            resume_data = self.load_resume_data()
            
            backup_data = {
                'backup_date': datetime.now().isoformat(),
                'app_version': '1.0.0',
                'resume_data': resume_data
            }
            
            return json.dumps(backup_data, indent=2, ensure_ascii=False)
            
        except Exception as e:
            st.error(f"Error creating backup: {str(e)}")
            return "{}"
    
    def restore_from_backup(self, backup_data: str) -> bool:
        """Restore resume data from backup"""
        try:
            backup = json.loads(backup_data)
            
            if 'resume_data' not in backup:
                st.error("Invalid backup format")
                return False
            
            resume_data = backup['resume_data']
            
            if not self._validate_resume_structure(resume_data):
                st.error("Invalid resume data in backup")
                return False
            
            return self.save_resume_data(resume_data)
            
        except json.JSONDecodeError:
            st.error("Invalid backup file format")
            return False
        except Exception as e:
            st.error(f"Error restoring from backup: {str(e)}")
            return False
