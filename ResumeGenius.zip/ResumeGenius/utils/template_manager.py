from typing import Dict, List, Any
import json

class TemplateManager:
    def __init__(self):
        """Initialize Template Manager with available templates"""
        self.templates = {
            'modern': {
                'name': 'Modern Professional',
                'description': 'Clean, modern design with subtle colors',
                'layout': 'single_column',
                'accent_position': 'left_border'
            },
            'executive': {
                'name': 'Executive',
                'description': 'Professional executive style with emphasis on experience',
                'layout': 'single_column',
                'accent_position': 'header'
            },
            'creative': {
                'name': 'Creative',
                'description': 'Modern design with creative flair',
                'layout': 'two_column',
                'accent_position': 'sidebar'
            },
            'technical': {
                'name': 'Technical',
                'description': 'Clean layout optimized for technical roles',
                'layout': 'single_column',
                'accent_position': 'section_headers'
            },
            'academic': {
                'name': 'Academic',
                'description': 'Traditional academic format',
                'layout': 'single_column',
                'accent_position': 'minimal'
            },
            'minimal': {
                'name': 'Minimal',
                'description': 'Clean, minimalist design',
                'layout': 'single_column',
                'accent_position': 'minimal'
            },
            'two_column': {
                'name': 'Two Column',
                'description': 'Efficient two-column layout',
                'layout': 'two_column',
                'accent_position': 'left_column'
            },
            'bold': {
                'name': 'Bold Impact',
                'description': 'Strong visual impact with bold styling',
                'layout': 'single_column',
                'accent_position': 'full_header'
            }
        }
    
    def get_available_templates(self) -> Dict[str, Dict]:
        """Get list of available templates"""
        return self.templates
    
    def generate_preview(self, resume_data: Dict, template_name: str, settings: Dict = None) -> str:
        """Generate HTML preview for the selected template"""
        if template_name not in self.templates:
            template_name = 'modern'
        
        template_info = self.templates[template_name]
        
        # Default settings
        if not settings:
            settings = {
                'color_scheme': 'Blue',
                'font_family': 'Arial',
                'font_size': 'Medium',
                'layout_density': 'Standard'
            }
        
        # Color schemes
        color_schemes = {
            'Blue': {'primary': '#2E86C1', 'secondary': '#85C1E9', 'text': '#2C3E50', 'light': '#EBF5FB'},
            'Green': {'primary': '#27AE60', 'secondary': '#82E5AA', 'text': '#2C3E50', 'light': '#E8F8F5'},
            'Purple': {'primary': '#8E44AD', 'secondary': '#C39BD3', 'text': '#2C3E50', 'light': '#F4F1F8'},
            'Red': {'primary': '#E74C3C', 'secondary': '#F1948A', 'text': '#2C3E50', 'light': '#FDEDEC'},
            'Orange': {'primary': '#E67E22', 'secondary': '#F8C471', 'text': '#2C3E50', 'light': '#FEF9E7'},
            'Teal': {'primary': '#16A085', 'secondary': '#7FB3D3', 'text': '#2C3E50', 'light': '#E8F6F3'},
            'Gray': {'primary': '#5D6D7E', 'secondary': '#BDC3C7', 'text': '#2C3E50', 'light': '#F8F9FA'}
        }
        
        colors = color_schemes.get(settings['color_scheme'], color_schemes['Blue'])
        
        # Font sizes
        font_sizes = {
            'Small': {'name': '16px', 'section': '14px', 'body': '11px', 'small': '10px'},
            'Medium': {'name': '20px', 'section': '16px', 'body': '12px', 'small': '11px'},
            'Large': {'name': '24px', 'section': '18px', 'body': '13px', 'small': '12px'}
        }
        
        fonts = font_sizes.get(settings['font_size'], font_sizes['Medium'])
        
        # Layout density spacing
        density_spacing = {
            'Compact': {'section': '15px', 'item': '8px', 'line': '1.3'},
            'Standard': {'section': '25px', 'item': '12px', 'line': '1.5'},
            'Spacious': {'section': '35px', 'item': '16px', 'line': '1.7'}
        }
        
        spacing = density_spacing.get(settings['layout_density'], density_spacing['Standard'])
        
        # Generate template-specific HTML
        if template_name == 'two_column' or template_name == 'creative':
            return self._generate_two_column_preview(resume_data, template_info, colors, fonts, spacing, settings)
        else:
            return self._generate_single_column_preview(resume_data, template_info, colors, fonts, spacing, settings)
    
    def _generate_single_column_preview(self, resume_data: Dict, template_info: Dict, 
                                      colors: Dict, fonts: Dict, spacing: Dict, settings: Dict) -> str:
        """Generate single column template preview"""
        
        # Template-specific styling
        header_style = ""
        if template_info['accent_position'] == 'full_header':
            header_style = f"background: linear-gradient(135deg, {colors['primary']}, {colors['secondary']}); color: white; padding: 30px; margin: -20px -20px 30px -20px;"
        elif template_info['accent_position'] == 'header':
            header_style = f"border-bottom: 4px solid {colors['primary']}; padding-bottom: 20px;"
        
        section_header_style = ""
        if template_info['accent_position'] == 'left_border':
            section_header_style = f"border-left: 4px solid {colors['primary']}; padding-left: 15px;"
        elif template_info['accent_position'] == 'section_headers':
            section_header_style = f"background: {colors['light']}; padding: 8px 15px; border-radius: 5px;"
        
        html_content = f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Resume Preview</title>
            <style>
                * {{
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }}
                
                body {{
                    font-family: {settings.get('font_family', 'Arial')}, sans-serif;
                    line-height: {spacing['line']};
                    color: {colors['text']};
                    background-color: #ffffff;
                    padding: 20px;
                }}
                
                .resume-container {{
                    max-width: 800px;
                    margin: 0 auto;
                    background: white;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                    padding: 40px;
                }}
                
                .header {{
                    text-align: center;
                    margin-bottom: {spacing['section']};
                    {header_style}
                }}
                
                .name {{
                    font-size: {fonts['name']};
                    font-weight: bold;
                    margin-bottom: 10px;
                    color: {'white' if 'full_header' in template_info['accent_position'] else colors['primary']};
                }}
                
                .contact-info {{
                    font-size: {fonts['body']};
                    margin-bottom: 5px;
                    color: {'rgba(255,255,255,0.9)' if 'full_header' in template_info['accent_position'] else colors['text']};
                }}
                
                .section {{
                    margin-bottom: {spacing['section']};
                }}
                
                .section-title {{
                    font-size: {fonts['section']};
                    font-weight: bold;
                    color: {colors['primary']};
                    margin-bottom: {spacing['item']};
                    text-transform: uppercase;
                    letter-spacing: 1px;
                    {section_header_style}
                }}
                
                .job-header {{
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    margin-bottom: 5px;
                    flex-wrap: wrap;
                }}
                
                .job-title {{
                    font-weight: bold;
                    font-size: {fonts['body']};
                    color: {colors['primary']};
                }}
                
                .company {{
                    font-weight: 600;
                    margin-left: 5px;
                }}
                
                .date-location {{
                    font-size: {fonts['small']};
                    color: #666;
                    font-style: italic;
                }}
                
                .bullet-point {{
                    margin: 3px 0 3px 20px;
                    font-size: {fonts['body']};
                    position: relative;
                }}
                
                .bullet-point:before {{
                    content: "•";
                    color: {colors['primary']};
                    font-weight: bold;
                    position: absolute;
                    left: -15px;
                }}
                
                .education-item, .project-item, .cert-item {{
                    margin-bottom: {spacing['item']};
                }}
                
                .education-header, .project-header, .cert-header {{
                    font-weight: bold;
                    color: {colors['primary']};
                    margin-bottom: 3px;
                }}
                
                .education-details, .project-details, .cert-details {{
                    font-size: {fonts['small']};
                    color: #666;
                    margin-bottom: 5px;
                }}
                
                .skills-grid {{
                    display: grid;
                    grid-template-columns: 1fr;
                    gap: 8px;
                }}
                
                .skill-category {{
                    font-size: {fonts['body']};
                }}
                
                .skill-category strong {{
                    color: {colors['primary']};
                    font-weight: 600;
                }}
                
                .summary-text {{
                    font-size: {fonts['body']};
                    line-height: {spacing['line']};
                    text-align: justify;
                }}
                
                @media (max-width: 768px) {{
                    .resume-container {{
                        padding: 20px;
                    }}
                    
                    .job-header {{
                        flex-direction: column;
                        align-items: flex-start;
                    }}
                }}
            </style>
        </head>
        <body>
            <div class="resume-container">
        """
        
        # Header - Personal Information
        personal = resume_data.get('personal', {})
        if personal.get('full_name'):
            html_content += f"""
            <div class="header">
                <div class="name">{personal['full_name']}</div>
            """
            
            contact_info = []
            if personal.get('email'):
                contact_info.append(personal['email'])
            if personal.get('phone'):
                contact_info.append(personal['phone'])
            if personal.get('location'):
                contact_info.append(personal['location'])
            
            if contact_info:
                html_content += f'<div class="contact-info">{" • ".join(contact_info)}</div>'
            
            if personal.get('linkedin') or personal.get('website'):
                links = []
                if personal.get('linkedin'):
                    links.append('LinkedIn')
                if personal.get('website'):
                    links.append('Portfolio')
                html_content += f'<div class="contact-info">{" • ".join(links)}</div>'
            
            html_content += "</div>"
        
        # Professional Summary
        if resume_data.get('summary'):
            html_content += f"""
            <div class="section">
                <div class="section-title">Professional Summary</div>
                <div class="summary-text">{resume_data['summary']}</div>
            </div>
            """
        
        # Work Experience
        work_exp = resume_data.get('work_experience', [])
        if work_exp:
            html_content += """
            <div class="section">
                <div class="section-title">Professional Experience</div>
            """
            
            for exp in work_exp:
                html_content += f"""
                <div style="margin-bottom: {spacing['item']};">
                    <div class="job-header">
                        <div>
                            <span class="job-title">{exp.get('job_title', '')}</span>
                            <span class="company">- {exp.get('company', '')}</span>
                        </div>
                        <div class="date-location">
                            {exp.get('start_date', '')} to {exp.get('end_date', 'Present')}
                            {' • ' + exp.get('location', '') if exp.get('location') else ''}
                        </div>
                    </div>
                """
                
                if exp.get('bullets'):
                    for bullet in exp['bullets']:
                        html_content += f'<div class="bullet-point">{bullet}</div>'
                
                html_content += "</div>"
            
            html_content += "</div>"
        
        # Education
        education = resume_data.get('education', [])
        if education:
            html_content += """
            <div class="section">
                <div class="section-title">Education</div>
            """
            
            for edu in education:
                html_content += f"""
                <div class="education-item">
                    <div class="education-header">{edu.get('degree', '')}
                """
                
                if edu.get('major'):
                    html_content += f" in {edu['major']}"
                
                html_content += f" - {edu.get('school', '')}</div>"
                
                details = []
                if edu.get('graduation_date'):
                    details.append(edu['graduation_date'])
                if edu.get('gpa'):
                    details.append(f"GPA: {edu['gpa']}")
                if edu.get('honors'):
                    details.append(edu['honors'])
                
                if details:
                    html_content += f'<div class="education-details">{" • ".join(details)}</div>'
                
                html_content += "</div>"
            
            html_content += "</div>"
        
        # Skills
        skills = resume_data.get('skills', {})
        if skills:
            html_content += """
            <div class="section">
                <div class="section-title">Skills</div>
                <div class="skills-grid">
            """
            
            for category, skill_list in skills.items():
                if skill_list:
                    html_content += f"""
                    <div class="skill-category">
                        <strong>{category}:</strong> {', '.join(skill_list)}
                    </div>
                    """
            
            html_content += "</div></div>"
        
        # Projects
        projects = resume_data.get('projects', [])
        if projects:
            html_content += """
            <div class="section">
                <div class="section-title">Projects</div>
            """
            
            for project in projects:
                html_content += f"""
                <div class="project-item">
                    <div class="project-header">{project.get('name', '')}
                """
                
                if project.get('technologies'):
                    html_content += f" ({project['technologies']})"
                
                html_content += "</div>"
                
                if project.get('date'):
                    html_content += f'<div class="project-details">{project["date"]}</div>'
                
                if project.get('description'):
                    html_content += f'<div>{project["description"]}</div>'
                
                html_content += "</div>"
            
            html_content += "</div>"
        
        # Certifications
        certifications = resume_data.get('certifications', [])
        if certifications:
            html_content += """
            <div class="section">
                <div class="section-title">Certifications</div>
            """
            
            for cert in certifications:
                html_content += f"""
                <div class="cert-item">
                    <div class="cert-header">{cert.get('name', '')} - {cert.get('issuer', '')}</div>
                """
                
                details = []
                if cert.get('date'):
                    details.append(cert['date'])
                if cert.get('id'):
                    details.append(f"ID: {cert['id']}")
                
                if details:
                    html_content += f'<div class="cert-details">{" • ".join(details)}</div>'
                
                html_content += "</div>"
            
            html_content += "</div>"
        
        html_content += """
            </div>
        </body>
        </html>
        """
        
        return html_content
    
    def _generate_two_column_preview(self, resume_data: Dict, template_info: Dict, 
                                   colors: Dict, fonts: Dict, spacing: Dict, settings: Dict) -> str:
        """Generate two column template preview"""
        
        html_content = f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Resume Preview - Two Column</title>
            <style>
                * {{
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }}
                
                body {{
                    font-family: {settings.get('font_family', 'Arial')}, sans-serif;
                    line-height: {spacing['line']};
                    color: {colors['text']};
                    background-color: #f8f9fa;
                    padding: 20px;
                }}
                
                .resume-container {{
                    max-width: 900px;
                    margin: 0 auto;
                    background: white;
                    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
                    display: grid;
                    grid-template-columns: 300px 1fr;
                    min-height: 100vh;
                }}
                
                .left-column {{
                    background: linear-gradient(135deg, {colors['primary']}, {colors['secondary']});
                    color: white;
                    padding: 30px 20px;
                }}
                
                .right-column {{
                    padding: 30px;
                }}
                
                .header {{
                    text-align: center;
                    margin-bottom: 30px;
                }}
                
                .name {{
                    font-size: {fonts['name']};
                    font-weight: bold;
                    margin-bottom: 10px;
                }}
                
                .contact-info {{
                    font-size: {fonts['small']};
                    margin-bottom: 5px;
                    opacity: 0.9;
                }}
                
                .section {{
                    margin-bottom: {spacing['section']};
                }}
                
                .section-title {{
                    font-size: {fonts['section']};
                    font-weight: bold;
                    margin-bottom: {spacing['item']};
                    text-transform: uppercase;
                    letter-spacing: 1px;
                    position: relative;
                    padding-bottom: 8px;
                }}
                
                .left-column .section-title {{
                    color: white;
                    border-bottom: 2px solid rgba(255,255,255,0.3);
                }}
                
                .right-column .section-title {{
                    color: {colors['primary']};
                    border-bottom: 2px solid {colors['secondary']};
                }}
                
                .job-header {{
                    margin-bottom: 8px;
                }}
                
                .job-title {{
                    font-weight: bold;
                    font-size: {fonts['body']};
                    color: {colors['primary']};
                }}
                
                .company {{
                    font-weight: 600;
                    margin-left: 5px;
                }}
                
                .date-location {{
                    font-size: {fonts['small']};
                    color: #666;
                    font-style: italic;
                    margin-bottom: 5px;
                }}
                
                .bullet-point {{
                    margin: 3px 0 3px 15px;
                    font-size: {fonts['body']};
                    position: relative;
                }}
                
                .bullet-point:before {{
                    content: "•";
                    color: {colors['primary']};
                    font-weight: bold;
                    position: absolute;
                    left: -15px;
                }}
                
                .left-column .bullet-point:before {{
                    color: rgba(255,255,255,0.8);
                }}
                
                .skill-item, .education-item {{
                    margin-bottom: {spacing['item']};
                    padding-bottom: {spacing['item']};
                    border-bottom: 1px solid rgba(255,255,255,0.2);
                }}
                
                .skill-item:last-child, .education-item:last-child {{
                    border-bottom: none;
                }}
                
                .skill-category {{
                    font-weight: bold;
                    margin-bottom: 5px;
                    font-size: {fonts['body']};
                }}
                
                .skill-list {{
                    font-size: {fonts['small']};
                    opacity: 0.9;
                }}
                
                .education-header {{
                    font-weight: bold;
                    font-size: {fonts['body']};
                    margin-bottom: 3px;
                }}
                
                .education-details {{
                    font-size: {fonts['small']};
                    opacity: 0.8;
                }}
                
                .summary-text {{
                    font-size: {fonts['body']};
                    line-height: {spacing['line']};
                    text-align: justify;
                }}
                
                .experience-item {{
                    margin-bottom: 20px;
                    padding-bottom: 15px;
                    border-bottom: 1px solid {colors['light']};
                }}
                
                .experience-item:last-child {{
                    border-bottom: none;
                }}
                
                @media (max-width: 768px) {{
                    .resume-container {{
                        grid-template-columns: 1fr;
                    }}
                    
                    .left-column {{
                        order: 2;
                    }}
                    
                    .right-column {{
                        order: 1;
                    }}
                }}
            </style>
        </head>
        <body>
            <div class="resume-container">
                <div class="left-column">
        """
        
        # Left column - Header and compact sections
        personal = resume_data.get('personal', {})
        if personal.get('full_name'):
            html_content += f"""
                    <div class="header">
                        <div class="name">{personal['full_name']}</div>
            """
            
            if personal.get('email'):
                html_content += f'<div class="contact-info">📧 {personal["email"]}</div>'
            if personal.get('phone'):
                html_content += f'<div class="contact-info">📞 {personal["phone"]}</div>'
            if personal.get('location'):
                html_content += f'<div class="contact-info">📍 {personal["location"]}</div>'
            if personal.get('linkedin'):
                html_content += f'<div class="contact-info">💼 LinkedIn Profile</div>'
            if personal.get('website'):
                html_content += f'<div class="contact-info">🌐 Portfolio</div>'
            
            html_content += "</div>"
        
        # Skills in left column
        skills = resume_data.get('skills', {})
        if skills:
            html_content += """
                    <div class="section">
                        <div class="section-title">Skills</div>
            """
            
            for category, skill_list in skills.items():
                if skill_list:
                    html_content += f"""
                        <div class="skill-item">
                            <div class="skill-category">{category}</div>
                            <div class="skill-list">{', '.join(skill_list)}</div>
                        </div>
                    """
            
            html_content += "</div>"
        
        # Education in left column
        education = resume_data.get('education', [])
        if education:
            html_content += """
                    <div class="section">
                        <div class="section-title">Education</div>
            """
            
            for edu in education:
                html_content += f"""
                    <div class="education-item">
                        <div class="education-header">{edu.get('degree', '')}</div>
                """
                
                if edu.get('major'):
                    html_content += f'<div class="education-details">{edu["major"]}</div>'
                
                html_content += f'<div class="education-details">{edu.get("school", "")}</div>'
                
                if edu.get('graduation_date'):
                    html_content += f'<div class="education-details">{edu["graduation_date"]}</div>'
                
                if edu.get('gpa'):
                    html_content += f'<div class="education-details">GPA: {edu["gpa"]}</div>'
                
                html_content += "</div>"
            
            html_content += "</div>"
        
        # Certifications in left column
        certifications = resume_data.get('certifications', [])
        if certifications:
            html_content += """
                    <div class="section">
                        <div class="section-title">Certifications</div>
            """
            
            for cert in certifications:
                html_content += f"""
                    <div class="skill-item">
                        <div class="skill-category">{cert.get('name', '')}</div>
                        <div class="skill-list">{cert.get('issuer', '')}</div>
                """
                
                if cert.get('date'):
                    html_content += f'<div class="skill-list">{cert["date"]}</div>'
                
                html_content += "</div>"
            
            html_content += "</div>"
        
        html_content += """
                </div>
                <div class="right-column">
        """
        
        # Right column - Main content
        
        # Professional Summary
        if resume_data.get('summary'):
            html_content += f"""
                    <div class="section">
                        <div class="section-title">Professional Summary</div>
                        <div class="summary-text">{resume_data['summary']}</div>
                    </div>
            """
        
        # Work Experience
        work_exp = resume_data.get('work_experience', [])
        if work_exp:
            html_content += """
                    <div class="section">
                        <div class="section-title">Professional Experience</div>
            """
            
            for exp in work_exp:
                html_content += f"""
                        <div class="experience-item">
                            <div class="job-header">
                                <span class="job-title">{exp.get('job_title', '')}</span>
                                <span class="company">- {exp.get('company', '')}</span>
                            </div>
                            <div class="date-location">
                                {exp.get('start_date', '')} to {exp.get('end_date', 'Present')}
                                {' • ' + exp.get('location', '') if exp.get('location') else ''}
                            </div>
                """
                
                if exp.get('bullets'):
                    for bullet in exp['bullets']:
                        html_content += f'<div class="bullet-point">{bullet}</div>'
                
                html_content += "</div>"
            
            html_content += "</div>"
        
        # Projects
        projects = resume_data.get('projects', [])
        if projects:
            html_content += """
                    <div class="section">
                        <div class="section-title">Projects</div>
            """
            
            for project in projects:
                html_content += f"""
                        <div class="experience-item">
                            <div class="job-header">
                                <span class="job-title">{project.get('name', '')}</span>
                """
                
                if project.get('technologies'):
                    html_content += f'<span class="company">- {project["technologies"]}</span>'
                
                html_content += "</div>"
                
                if project.get('date'):
                    html_content += f'<div class="date-location">{project["date"]}</div>'
                
                if project.get('description'):
                    html_content += f'<div class="bullet-point">{project["description"]}</div>'
                
                if project.get('url'):
                    html_content += f'<div class="date-location">🔗 Project URL Available</div>'
                
                html_content += "</div>"
            
            html_content += "</div>"
        
        html_content += """
                </div>
            </div>
        </body>
        </html>
        """
        
        return html_content
