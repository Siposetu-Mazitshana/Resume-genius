import streamlit as st
from utils.storage_manager import StorageManager

def render_landing_page():
    """Render the landing page with welcome content and navigation"""
    
    # Custom CSS for landing page
    st.markdown("""
    <style>
    .landing-hero {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 3rem 2rem;
        border-radius: 15px;
        text-align: center;
        color: white;
        margin: 2rem 0;
    }
    
    .feature-card {
        background: white;
        padding: 2rem;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        margin: 1rem 0;
        border-left: 4px solid #667eea;
    }
    
    .stat-card {
        background: linear-gradient(45deg, #f093fb 0%, #f5576c 100%);
        padding: 1.5rem;
        border-radius: 10px;
        text-align: center;
        color: white;
        margin: 0.5rem;
    }
    
    .cta-button {
        background: linear-gradient(45deg, #667eea, #764ba2);
        color: white;
        padding: 0.8rem 2rem;
        border-radius: 25px;
        border: none;
        font-size: 1.1rem;
        font-weight: bold;
        cursor: pointer;
        margin: 1rem 0.5rem;
        transition: transform 0.2s;
    }
    
    .cta-button:hover {
        transform: translateY(-2px);
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Hero Section
    st.markdown("""
    <div class="landing-hero">
        <h1 style="font-size: 3rem; margin-bottom: 1rem;">🎯 TAC Resume Builder</h1>
        <h3 style="font-weight: 300; margin-bottom: 2rem;">AI-Powered Professional Resume Generator</h3>
        <p style="font-size: 1.2rem; opacity: 0.9;">Create stunning, ATS-optimized resumes in minutes with the power of artificial intelligence</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Statistics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        <div class="stat-card">
            <h2>8+</h2>
            <p>Professional Templates</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="stat-card">
            <h2>3</h2>
            <p>Export Formats</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div class="stat-card">
            <h2>AI</h2>
            <p>Powered Content</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown("""
        <div class="stat-card">
            <h2>100%</h2>
            <p>Privacy Focused</p>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Main Action Buttons
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        if st.button("🚀 Start Building Your Resume", type="primary", use_container_width=True):
            st.session_state.current_page = "builder"
            st.rerun()
        
        if st.button("📁 Load Existing Resume", use_container_width=True):
            st.session_state.current_page = "builder"
            st.session_state.current_step = 0
            st.rerun()
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Features Section
    st.markdown("## ✨ Key Features")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        <div class="feature-card">
            <h4>🤖 AI-Powered Content Generation</h4>
            <p>Let our AI create professional summaries, compelling bullet points, and suggest relevant skills based on your experience and target role.</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="feature-card">
            <h4>📄 Multiple Export Formats</h4>
            <p>Download your resume in PDF, DOCX, or HTML formats. All exports maintain professional formatting and ATS compatibility.</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="feature-card">
            <h4>🔒 Privacy & Security</h4>
            <p>Your data stays private with local storage. Work offline and maintain complete control over your personal information.</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="feature-card">
            <h4>🎨 Professional Templates</h4>
            <p>Choose from 8+ carefully designed templates including Modern, Executive, Creative, Technical, Academic, and more.</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="feature-card">
            <h4>⚡ Real-time Preview</h4>
            <p>See your resume come to life as you build it with our live preview feature. Customize colors, fonts, and layouts instantly.</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="feature-card">
            <h4>🎯 ATS Optimization</h4>
            <p>Built-in ATS optimization ensures your resume passes through applicant tracking systems and reaches human recruiters.</p>
        </div>
        """, unsafe_allow_html=True)
    
    # How It Works Section
    st.markdown("## 🔄 How It Works")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        ### 1. 📝 Enter Your Information
        Fill in your personal details, work experience, education, and skills using our intuitive step-by-step form.
        """)
    
    with col2:
        st.markdown("""
        ### 2. 🤖 Let AI Enhance
        Use our AI features to generate professional content, optimize for keywords, and improve your resume's impact.
        """)
    
    with col3:
        st.markdown("""
        ### 3. 📄 Export & Apply
        Choose your preferred template and format, then download your professional resume ready for job applications.
        """)
    
    # Quick Stats
    storage_mgr = StorageManager()
    stats = storage_mgr.get_resume_statistics()
    
    if stats['completion_percentage'] > 0:
        st.markdown("## 📊 Your Progress")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Completion", f"{stats['completion_percentage']:.0f}%")
        
        with col2:
            st.metric("Sections Completed", f"{stats['sections_completed']}/{stats['total_sections']}")
        
        with col3:
            st.metric("Word Count", stats['word_count'])
        
        if stats['completion_percentage'] > 50:
            st.success("Great progress! Your resume is looking good. Keep going!")
        elif stats['completion_percentage'] > 0:
            st.info("You've started building your resume. Continue where you left off!")

def render_ai_suggestions():
    """Render AI suggestions and tips"""
    st.markdown("## 🧠 AI Suggestions & Tips")
    
    # AI Suggestions based on current resume state
    if 'resume_data' in st.session_state:
        resume_data = st.session_state.resume_data
        
        suggestions = []
        
        # Check completeness and provide suggestions
        if not resume_data['personal'].get('full_name'):
            suggestions.append("💡 Start by adding your personal information to create a strong foundation.")
        
        if not resume_data.get('summary'):
            suggestions.append("📝 Add a professional summary to make a great first impression.")
        
        if len(resume_data.get('work_experience', [])) == 0:
            suggestions.append("💼 Add your work experience to showcase your professional background.")
        
        if len(resume_data.get('skills', {})) == 0:
            suggestions.append("🛠️ Include relevant skills to highlight your capabilities.")
        
        if len(resume_data.get('education', [])) == 0:
            suggestions.append("🎓 Add your educational background to complete your profile.")
        
        # Display suggestions
        if suggestions:
            st.markdown("### 📋 Next Steps")
            for suggestion in suggestions:
                st.markdown(f"- {suggestion}")
        else:
            st.success("🎉 Your resume looks complete! Consider using AI to enhance your content.")
    
    # General tips
    st.markdown("### 💡 Professional Tips")
    
    tips = [
        "Use action verbs to start your bullet points (e.g., 'Managed', 'Developed', 'Led')",
        "Quantify your achievements with numbers and percentages when possible",
        "Tailor your resume for each job application by emphasizing relevant skills",
        "Keep your resume to 1-2 pages for most positions",
        "Use consistent formatting and professional fonts",
        "Proofread carefully for spelling and grammar errors",
        "Include keywords from the job description to pass ATS systems",
        "Focus on accomplishments rather than just job duties"
    ]
    
    for i, tip in enumerate(tips, 1):
        st.markdown(f"**{i}.** {tip}")

def render_template_showcase():
    """Render template showcase"""
    st.markdown("## 🎨 Template Showcase")
    
    templates = {
        'modern': {
            'name': 'Modern Professional',
            'description': 'Clean, contemporary design perfect for tech and business roles',
            'best_for': 'Software Engineers, Business Analysts, Project Managers'
        },
        'executive': {
            'name': 'Executive',
            'description': 'Sophisticated layout emphasizing leadership and experience',
            'best_for': 'Senior Managers, Directors, C-Level Executives'
        },
        'creative': {
            'name': 'Creative',
            'description': 'Vibrant two-column design for creative professionals',
            'best_for': 'Designers, Marketers, Content Creators'
        },
        'technical': {
            'name': 'Technical',
            'description': 'Clean, structured format optimized for technical roles',
            'best_for': 'Developers, Engineers, Data Scientists'
        },
        'academic': {
            'name': 'Academic',
            'description': 'Traditional format suitable for academic and research positions',
            'best_for': 'Researchers, Professors, PhD Candidates'
        },
        'minimal': {
            'name': 'Minimal',
            'description': 'Simple, elegant design focusing on content',
            'best_for': 'Any profession preferring clean aesthetics'
        },
        'two_column': {
            'name': 'Two Column',
            'description': 'Efficient layout maximizing space utilization',
            'best_for': 'Professionals with extensive experience'
        },
        'bold': {
            'name': 'Bold Impact',
            'description': 'Strong visual design that stands out',
            'best_for': 'Sales, Marketing, Leadership roles'
        }
    }
    
    cols = st.columns(2)
    
    for i, (template_id, template_info) in enumerate(templates.items()):
        col = cols[i % 2]
        
        with col:
            with st.container():
                st.markdown(f"### {template_info['name']}")
                st.markdown(f"**Description:** {template_info['description']}")
                st.markdown(f"**Best for:** {template_info['best_for']}")
                
                if st.button(f"Preview {template_info['name']}", key=f"preview_{template_id}"):
                    st.session_state.selected_template = template_id
                    st.session_state.current_page = "builder"
                    st.session_state.current_step = 6  # Go to template selection
                    st.rerun()
                
                st.markdown("---")