import streamlit as st
import json
from utils.storage_manager import StorageManager

def render_settings_page():
    """Render the settings and configuration page"""
    
    st.markdown("## ⚙️ Settings & Configuration")
    
    # API Keys Management
    st.markdown("### 🔑 API Keys Management")
    
    with st.expander("OpenAI API Configuration", expanded=True):
        st.markdown("""
        **Current Status:** Connected ✅
        
        The OpenAI API is used for:
        - Generating professional summaries
        - Creating job bullet points
        - Suggesting relevant skills
        - Optimizing content for ATS systems
        """)
        
        if st.button("🔄 Test OpenAI Connection"):
            try:
                from utils.ai_generator import AIGenerator
                ai_gen = AIGenerator()
                test_summary = ai_gen.generate_professional_summary(
                    "Software Engineer", 3, "Technology", {}
                )
                if "Error" not in test_summary:
                    st.success("✅ OpenAI API connection successful!")
                else:
                    st.error(f"❌ OpenAI API Error: {test_summary}")
            except Exception as e:
                st.error(f"❌ Connection failed: {str(e)}")
    
    with st.expander("Additional API Integrations"):
        st.markdown("### Add New API Integration")
        
        api_service = st.selectbox(
            "Select API Service",
            ["LinkedIn API", "GitHub API", "Google Drive API", "Dropbox API", "Custom API"]
        )
        
        if api_service == "LinkedIn API":
            st.markdown("""
            **LinkedIn API Integration**
            - Auto-import profile information
            - Sync work experience and skills
            - Import recommendations
            """)
            
            linkedin_key = st.text_input("LinkedIn API Key", type="password", placeholder="Enter your LinkedIn API key")
            linkedin_secret = st.text_input("LinkedIn API Secret", type="password", placeholder="Enter your LinkedIn API secret")
            
            if st.button("Connect LinkedIn"):
                if linkedin_key and linkedin_secret:
                    st.success("LinkedIn API configured successfully!")
                    st.info("Feature will be available in the next update.")
                else:
                    st.error("Please provide both API key and secret.")
        
        elif api_service == "GitHub API":
            st.markdown("""
            **GitHub API Integration**
            - Import repository information
            - Auto-generate project descriptions
            - Showcase technical skills
            """)
            
            github_token = st.text_input("GitHub Personal Access Token", type="password", placeholder="Enter your GitHub token")
            
            if st.button("Connect GitHub"):
                if github_token:
                    st.success("GitHub API configured successfully!")
                    st.info("Feature will be available in the next update.")
                else:
                    st.error("Please provide your GitHub token.")
        
        elif api_service == "Custom API":
            st.markdown("**Custom API Integration**")
            api_name = st.text_input("API Name", placeholder="e.g., My Custom Service")
            api_endpoint = st.text_input("API Endpoint", placeholder="https://api.example.com")
            api_key = st.text_input("API Key", type="password", placeholder="Enter API key")
            
            if st.button("Add Custom API"):
                if api_name and api_endpoint and api_key:
                    st.success(f"Custom API '{api_name}' configured successfully!")
                    st.info("Custom API integrations will be available in future updates.")
                else:
                    st.error("Please fill in all fields.")
    
    st.divider()
    
    # Offline Mode Settings
    st.markdown("### 📱 Offline Mode Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Current Offline Capabilities")
        st.markdown("""
        ✅ **Fully Offline:**
        - Resume building and editing
        - Template customization
        - Local data storage
        - Preview generation
        - HTML export
        
        ⚠️ **Requires Internet:**
        - AI content generation
        - PDF/DOCX export (libraries)
        """)
    
    with col2:
        st.markdown("#### Offline Data Management")
        
        storage_mgr = StorageManager()
        
        if st.button("📥 Create Offline Backup"):
            backup_data = storage_mgr.create_backup()
            st.download_button(
                label="💾 Download Backup File",
                data=backup_data,
                file_name=f"resume_backup_{st.session_state.get('current_timestamp', 'latest')}.json",
                mime="application/json"
            )
            st.success("Backup created successfully!")
        
        uploaded_file = st.file_uploader("📤 Restore from Backup", type=['json'])
        if uploaded_file is not None:
            try:
                backup_content = uploaded_file.read().decode('utf-8')
                if storage_mgr.restore_from_backup(backup_content):
                    st.success("Resume data restored successfully!")
                    st.rerun()
                else:
                    st.error("Failed to restore backup. Please check the file format.")
            except Exception as e:
                st.error(f"Error reading backup file: {str(e)}")
    
    st.divider()
    
    # Export Settings
    st.markdown("### 📄 Export Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Default Export Settings")
        
        default_format = st.selectbox(
            "Default Export Format",
            ["PDF", "DOCX", "HTML"],
            index=0
        )
        
        include_metadata = st.checkbox("Include creation metadata in exports", value=True)
        
        optimize_for_ats = st.checkbox("Auto-optimize for ATS systems", value=True)
        
        if st.button("💾 Save Export Settings"):
            export_settings = {
                'default_format': default_format,
                'include_metadata': include_metadata,
                'optimize_for_ats': optimize_for_ats
            }
            st.session_state.export_settings = export_settings
            st.success("Export settings saved!")
    
    with col2:
        st.markdown("#### Export Quality Settings")
        
        pdf_quality = st.selectbox(
            "PDF Quality",
            ["High (Print Ready)", "Medium (Web Optimized)", "Low (Small File)"],
            index=0
        )
        
        image_dpi = st.selectbox(
            "Image DPI (for graphics)",
            ["300 DPI (High)", "150 DPI (Medium)", "72 DPI (Web)"],
            index=1
        )
        
        font_embedding = st.checkbox("Embed fonts in PDF", value=True)
    
    st.divider()
    
    # Privacy Settings
    st.markdown("### 🔒 Privacy & Data Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Data Storage")
        st.markdown("""
        **Local Storage Only** 🔒
        - All your data is stored locally in your browser
        - No data is sent to external servers (except AI API calls)
        - You have complete control over your information
        """)
        
        auto_save = st.checkbox("Auto-save changes", value=True)
        save_frequency = st.selectbox(
            "Auto-save frequency",
            ["Every change", "Every 30 seconds", "Every minute", "Every 5 minutes"],
            index=2
        )
    
    with col2:
        st.markdown("#### Data Management")
        
        storage_stats = storage_mgr.get_resume_statistics()
        
        st.markdown(f"""
        **Current Usage:**
        - Completion: {storage_stats['completion_percentage']:.0f}%
        - Word Count: {storage_stats['word_count']}
        - Last Updated: {storage_stats.get('last_updated', 'Never')}
        """)
        
        if st.button("🗑️ Clear All Data", type="secondary"):
            if st.checkbox("I understand this will delete all my resume data"):
                if storage_mgr.clear_resume_data():
                    st.success("All data cleared successfully!")
                    st.rerun()
    
    st.divider()
    
    # Application Settings
    st.markdown("### 🎨 Application Preferences")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Interface Settings")
        
        theme_preference = st.selectbox(
            "Theme Preference",
            ["Light", "Dark", "Auto (System)"],
            index=0
        )
        
        sidebar_default = st.selectbox(
            "Sidebar Default State",
            ["Expanded", "Collapsed"],
            index=0
        )
        
        show_tips = st.checkbox("Show helpful tips", value=True)
        show_preview = st.checkbox("Show live preview by default", value=True)
    
    with col2:
        st.markdown("#### Language & Localization")
        
        language = st.selectbox(
            "Interface Language",
            ["English", "Spanish", "French", "German", "Portuguese"],
            index=0
        )
        
        date_format = st.selectbox(
            "Date Format",
            ["MM/YYYY", "YYYY-MM", "Month YYYY"],
            index=0
        )
        
        st.info("Multi-language support coming in future updates!")
    
    # Save all settings
    if st.button("💾 Save All Settings", type="primary"):
        app_settings = {
            'theme_preference': theme_preference,
            'sidebar_default': sidebar_default,
            'show_tips': show_tips,
            'show_preview': show_preview,
            'language': language,
            'date_format': date_format,
            'auto_save': auto_save,
            'save_frequency': save_frequency
        }
        st.session_state.app_settings = app_settings
        st.success("All settings saved successfully!")

def render_help_page():
    """Render the help and documentation page"""
    
    st.markdown("## 📚 Help & Documentation")
    
    # Quick Start Guide
    with st.expander("🚀 Quick Start Guide", expanded=True):
        st.markdown("""
        ### Getting Started with TAC Resume Builder
        
        1. **Start on the Landing Page**
           - Click "Start Building Your Resume" to begin
           - Or load an existing resume if you have one
        
        2. **Fill in Your Information**
           - Personal Information: Name, contact details
           - Professional Summary: Brief overview of your background
           - Work Experience: Job history with AI-generated bullet points
           - Education: Academic background
           - Skills: Relevant technical and soft skills
        
        3. **Use AI Features**
           - Generate professional summaries
           - Create compelling bullet points
           - Get skill suggestions for your role
        
        4. **Choose a Template**
           - Browse 8+ professional templates
           - Customize colors, fonts, and layout
           - See real-time preview
        
        5. **Export Your Resume**
           - Download in PDF, DOCX, or HTML format
           - All formats are ATS-optimized
        """)
    
    # FAQ Section
    with st.expander("❓ Frequently Asked Questions"):
        st.markdown("""
        ### Common Questions
        
        **Q: Is my data secure?**
        A: Yes! All your data is stored locally in your browser. We don't send your personal information to any servers except for AI processing when you use AI features.
        
        **Q: Can I use this offline?**
        A: Most features work offline including resume building, editing, and HTML export. AI features and PDF/DOCX export require an internet connection.
        
        **Q: How do I get an OpenAI API key?**
        A: Visit https://platform.openai.com, create an account, and generate an API key in the API Keys section.
        
        **Q: Are the resumes ATS-friendly?**
        A: Yes! All our templates are designed to pass through Applicant Tracking Systems (ATS) while maintaining professional appearance.
        
        **Q: Can I customize the templates?**
        A: Yes! You can change colors, fonts, font sizes, and layout density for any template.
        
        **Q: How do I save my progress?**
        A: Your progress is automatically saved to your browser's local storage. You can also create backups to download and restore later.
        """)
    
    # AI Features Guide
    with st.expander("🤖 AI Features Guide"):
        st.markdown("""
        ### AI-Powered Features
        
        **Professional Summary Generation**
        - Enter your job title, years of experience, and industry
        - AI creates a compelling 3-4 sentence summary
        - Optimized for your target role
        
        **Job Bullet Point Creation**
        - Provide job title and brief description
        - AI generates 4-6 impactful bullet points
        - Uses action verbs and quantifiable achievements
        
        **Skill Suggestions**
        - Enter your target job role
        - AI suggests relevant technical and soft skills
        - Organized by categories
        
        **ATS Optimization**
        - Analyzes your resume content
        - Suggests improvements for better ATS compatibility
        - Provides keyword recommendations
        """)
    
    # Template Guide
    with st.expander("🎨 Template Selection Guide"):
        st.markdown("""
        ### Choosing the Right Template
        
        **Modern Professional** - Clean, contemporary design
        - Best for: Tech, Business, General roles
        
        **Executive** - Sophisticated, experience-focused
        - Best for: Senior management, Leadership roles
        
        **Creative** - Vibrant, two-column design
        - Best for: Design, Marketing, Creative roles
        
        **Technical** - Clean, structured format
        - Best for: Engineering, Development, Technical roles
        
        **Academic** - Traditional, research-oriented
        - Best for: Academic, Research, Education roles
        
        **Minimal** - Simple, content-focused
        - Best for: Any profession preferring clean aesthetics
        
        **Two Column** - Space-efficient layout
        - Best for: Extensive experience, Multiple skills
        
        **Bold Impact** - Strong visual presence
        - Best for: Sales, Marketing, Leadership roles
        """)
    
    # Troubleshooting
    with st.expander("🔧 Troubleshooting"):
        st.markdown("""
        ### Common Issues and Solutions
        
        **AI Features Not Working**
        - Check your OpenAI API key in Settings
        - Ensure you have internet connection
        - Verify API key has sufficient credits
        
        **Export Not Working**
        - Try a different export format
        - Check internet connection for PDF/DOCX
        - HTML export works offline
        
        **Data Not Saving**
        - Check if browser cookies are enabled
        - Clear browser cache and try again
        - Create a backup before clearing data
        
        **Preview Not Updating**
        - Refresh the page
        - Check if all required fields are filled
        - Try switching templates
        
        **Performance Issues**
        - Close other browser tabs
        - Clear browser cache
        - Disable browser extensions temporarily
        """)
    
    # Contact and Support
    st.markdown("### 📞 Support")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        **Need More Help?**
        - Check our FAQ section above
        - Try the troubleshooting guide
        - Reset your data and start fresh
        """)
    
    with col2:
        st.markdown("""
        **Feature Requests**
        - We're constantly improving
        - New features added regularly
        - Your feedback shapes our development
        """)