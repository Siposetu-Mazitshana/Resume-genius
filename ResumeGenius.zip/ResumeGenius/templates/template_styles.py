from typing import Dict, List, Any

class TemplateStyles:
    """
    Centralized template styling definitions for consistent design across all export formats
    """
    
    def __init__(self):
        self.color_schemes = {
            'Blue': {
                'primary': '#2E86C1',
                'secondary': '#85C1E9', 
                'accent': '#1B4F72',
                'text': '#2C3E50',
                'light': '#EBF5FB',
                'background': '#FFFFFF'
            },
            'Green': {
                'primary': '#27AE60',
                'secondary': '#82E5AA',
                'accent': '#196F3D',
                'text': '#2C3E50',
                'light': '#E8F8F5',
                'background': '#FFFFFF'
            },
            'Purple': {
                'primary': '#8E44AD',
                'secondary': '#C39BD3',
                'accent': '#633974',
                'text': '#2C3E50',
                'light': '#F4F1F8',
                'background': '#FFFFFF'
            },
            'Red': {
                'primary': '#E74C3C',
                'secondary': '#F1948A',
                'accent': '#A93226',
                'text': '#2C3E50',
                'light': '#FDEDEC',
                'background': '#FFFFFF'
            },
            'Orange': {
                'primary': '#E67E22',
                'secondary': '#F8C471',
                'accent': '#AF601A',
                'text': '#2C3E50',
                'light': '#FEF9E7',
                'background': '#FFFFFF'
            },
            'Teal': {
                'primary': '#16A085',
                'secondary': '#7FB3D3',
                'accent': '#0E6655',
                'text': '#2C3E50',
                'light': '#E8F6F3',
                'background': '#FFFFFF'
            },
            'Gray': {
                'primary': '#5D6D7E',
                'secondary': '#BDC3C7',
                'accent': '#34495E',
                'text': '#2C3E50',
                'light': '#F8F9FA',
                'background': '#FFFFFF'
            }
        }
        
        self.font_families = {
            'Arial': ['Arial', 'sans-serif'],
            'Helvetica': ['Helvetica', 'Arial', 'sans-serif'],
            'Times New Roman': ['Times New Roman', 'Times', 'serif'],
            'Calibri': ['Calibri', 'Arial', 'sans-serif'],
            'Georgia': ['Georgia', 'Times', 'serif']
        }
        
        self.font_sizes = {
            'Small': {
                'name': {'pt': 16, 'px': '18px'},
                'section': {'pt': 12, 'px': '14px'},
                'body': {'pt': 9, 'px': '11px'},
                'small': {'pt': 8, 'px': '10px'}
            },
            'Medium': {
                'name': {'pt': 18, 'px': '20px'},
                'section': {'pt': 14, 'px': '16px'},
                'body': {'pt': 10, 'px': '12px'},
                'small': {'pt': 9, 'px': '11px'}
            },
            'Large': {
                'name': {'pt': 22, 'px': '24px'},
                'section': {'pt': 16, 'px': '18px'},
                'body': {'pt': 11, 'px': '13px'},
                'small': {'pt': 10, 'px': '12px'}
            }
        }
        
        self.layout_density = {
            'Compact': {
                'section_spacing': {'pt': 10, 'px': '15px'},
                'item_spacing': {'pt': 6, 'px': '8px'},
                'line_height': 1.3,
                'paragraph_spacing': {'pt': 4, 'px': '6px'}
            },
            'Standard': {
                'section_spacing': {'pt': 16, 'px': '25px'},
                'item_spacing': {'pt': 8, 'px': '12px'},
                'line_height': 1.5,
                'paragraph_spacing': {'pt': 6, 'px': '10px'}
            },
            'Spacious': {
                'section_spacing': {'pt': 24, 'px': '35px'},
                'item_spacing': {'pt': 12, 'px': '16px'},
                'line_height': 1.7,
                'paragraph_spacing': {'pt': 8, 'px': '14px'}
            }
        }
        
        self.template_configurations = {
            'modern': {
                'name': 'Modern Professional',
                'layout_type': 'single_column',
                'header_style': 'centered_with_border',
                'section_style': 'left_border_accent',
                'bullet_style': 'colored_bullets',
                'emphasis_style': 'bold_primary_color'
            },
            'executive': {
                'name': 'Executive',
                'layout_type': 'single_column',
                'header_style': 'centered_professional',
                'section_style': 'underlined_headers',
                'bullet_style': 'standard_bullets',
                'emphasis_style': 'bold_traditional'
            },
            'creative': {
                'name': 'Creative',
                'layout_type': 'two_column',
                'header_style': 'gradient_header',
                'section_style': 'background_accent',
                'bullet_style': 'icon_bullets',
                'emphasis_style': 'colored_emphasis'
            },
            'technical': {
                'name': 'Technical',
                'layout_type': 'single_column',
                'header_style': 'minimal_centered',
                'section_style': 'clean_headers',
                'bullet_style': 'dash_bullets',
                'emphasis_style': 'monospace_accent'
            },
            'academic': {
                'name': 'Academic',
                'layout_type': 'single_column',
                'header_style': 'traditional',
                'section_style': 'traditional_headers',
                'bullet_style': 'traditional_bullets',
                'emphasis_style': 'italic_emphasis'
            },
            'minimal': {
                'name': 'Minimal',
                'layout_type': 'single_column',
                'header_style': 'simple',
                'section_style': 'minimal_headers',
                'bullet_style': 'minimal_bullets',
                'emphasis_style': 'subtle_emphasis'
            },
            'two_column': {
                'name': 'Two Column',
                'layout_type': 'two_column',
                'header_style': 'split_header',
                'section_style': 'column_specific',
                'bullet_style': 'standard_bullets',
                'emphasis_style': 'column_appropriate'
            },
            'bold': {
                'name': 'Bold Impact',
                'layout_type': 'single_column',
                'header_style': 'full_width_background',
                'section_style': 'bold_headers',
                'bullet_style': 'large_bullets',
                'emphasis_style': 'strong_emphasis'
            }
        }
    
    def get_template_style(self, template_name: str, settings: Dict[str, str]) -> Dict[str, Any]:
        """
        Get complete styling configuration for a template with user settings
        """
        template_config = self.template_configurations.get(template_name, self.template_configurations['modern'])
        
        color_scheme = settings.get('color_scheme', 'Blue')
        font_family = settings.get('font_family', 'Arial')
        font_size = settings.get('font_size', 'Medium')
        density = settings.get('layout_density', 'Standard')
        
        colors = self.color_schemes.get(color_scheme, self.color_schemes['Blue'])
        fonts = self.font_families.get(font_family, self.font_families['Arial'])
        sizes = self.font_sizes.get(font_size, self.font_sizes['Medium'])
        spacing = self.layout_density.get(density, self.layout_density['Standard'])
        
        return {
            'template_config': template_config,
            'colors': colors,
            'font_family': fonts,
            'font_sizes': sizes,
            'spacing': spacing,
            'settings': settings
        }
    
    def get_css_styles(self, template_name: str, settings: Dict[str, str]) -> str:
        """
        Generate CSS styles for HTML export
        """
        style_config = self.get_template_style(template_name, settings)
        
        colors = style_config['colors']
        fonts = style_config['font_sizes']
        spacing = style_config['spacing']
        font_family = ', '.join(style_config['font_family'])
        
        css = f"""
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: {font_family};
            font-size: {fonts['body']['px']};
            line-height: {spacing['line_height']};
            color: {colors['text']};
            background-color: {colors['background']};
            padding: 20px;
        }}
        
        .resume-container {{
            max-width: 800px;
            margin: 0 auto;
            background: {colors['background']};
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 40px;
        }}
        
        .header {{
            text-align: center;
            margin-bottom: {spacing['section_spacing']['px']};
            padding-bottom: 20px;
            border-bottom: 3px solid {colors['primary']};
        }}
        
        .name {{
            font-size: {fonts['name']['px']};
            font-weight: bold;
            color: {colors['primary']};
            margin-bottom: {spacing['item_spacing']['px']};
        }}
        
        .contact-info {{
            font-size: {fonts['body']['px']};
            margin-bottom: 5px;
            color: {colors['text']};
        }}
        
        .section {{
            margin-bottom: {spacing['section_spacing']['px']};
        }}
        
        .section-title {{
            font-size: {fonts['section']['px']};
            font-weight: bold;
            color: {colors['primary']};
            margin-bottom: {spacing['item_spacing']['px']};
            text-transform: uppercase;
            letter-spacing: 1px;
            border-bottom: 2px solid {colors['secondary']};
            padding-bottom: 5px;
        }}
        
        .job-title {{
            font-weight: bold;
            color: {colors['primary']};
            font-size: {fonts['body']['px']};
        }}
        
        .company {{
            font-weight: 600;
            color: {colors['text']};
        }}
        
        .date-range {{
            font-style: italic;
            color: {colors['accent']};
            font-size: {fonts['small']['px']};
            margin-bottom: 5px;
        }}
        
        .bullet-point {{
            margin: 3px 0 3px 20px;
            position: relative;
            font-size: {fonts['body']['px']};
        }}
        
        .bullet-point:before {{
            content: "•";
            color: {colors['primary']};
            font-weight: bold;
            position: absolute;
            left: -15px;
        }}
        
        .skill-category {{
            margin-bottom: {spacing['item_spacing']['px']};
            font-size: {fonts['body']['px']};
        }}
        
        .skill-category strong {{
            color: {colors['primary']};
            font-weight: 600;
        }}
        
        .education-item, .project-item, .cert-item {{
            margin-bottom: {spacing['item_spacing']['px']};
        }}
        
        .education-header, .project-header, .cert-header {{
            font-weight: bold;
            color: {colors['primary']};
            margin-bottom: 3px;
        }}
        
        .education-details, .project-details, .cert-details {{
            font-size: {fonts['small']['px']};
            color: {colors['accent']};
            margin-bottom: 5px;
        }}
        
        @media print {{
            body {{
                margin: 0;
                padding: 10px;
            }}
            .resume-container {{
                box-shadow: none;
                padding: 20px;
            }}
            .section {{
                page-break-inside: avoid;
            }}
        }}
        """
        
        # Add template-specific styles
        template_config = style_config['template_config']
        
        if template_config['layout_type'] == 'two_column':
            css += self._get_two_column_css(colors, fonts, spacing, font_family)
        
        if template_config['header_style'] == 'gradient_header':
            css += f"""
            .header {{
                background: linear-gradient(135deg, {colors['primary']}, {colors['secondary']});
                color: white;
                padding: 30px;
                margin: -40px -40px 30px -40px;
                border-bottom: none;
            }}
            
            .header .name {{
                color: white;
            }}
            
            .header .contact-info {{
                color: rgba(255,255,255,0.9);
            }}
            """
        
        if template_config['section_style'] == 'left_border_accent':
            css += f"""
            .section-title {{
                border-left: 4px solid {colors['primary']};
                padding-left: 15px;
                border-bottom: 1px solid {colors['secondary']};
            }}
            """
        
        return css
    
    def _get_two_column_css(self, colors: Dict, fonts: Dict, spacing: Dict, font_family: str) -> str:
        """Generate CSS for two-column layouts"""
        return f"""
        .resume-container {{
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 0;
            max-width: 900px;
        }}
        
        .left-column {{
            background: linear-gradient(135deg, {colors['primary']}, {colors['secondary']});
            color: white;
            padding: 30px 20px;
        }}
        
        .right-column {{
            padding: 30px;
            background: {colors['background']};
        }}
        
        .left-column .section-title {{
            color: white;
            border-bottom: 2px solid rgba(255,255,255,0.3);
            border-left: none;
            padding-left: 0;
        }}
        
        .left-column .skill-category strong {{
            color: rgba(255,255,255,0.9);
        }}
        
        .left-column .contact-info {{
            color: rgba(255,255,255,0.9);
        }}
        
        @media (max-width: 768px) {{
            .resume-container {{
                grid-template-columns: 1fr;
            }}
            
            .left-column {{
                order: 2;
            }}
            
            .right-column {{
                order: 1;
            }}
        }}
        """
    
    def get_available_color_schemes(self) -> List[str]:
        """Get list of available color schemes"""
        return list(self.color_schemes.keys())
    
    def get_available_fonts(self) -> List[str]:
        """Get list of available font families"""
        return list(self.font_families.keys())
    
    def get_available_font_sizes(self) -> List[str]:
        """Get list of available font sizes"""
        return list(self.font_sizes.keys())
    
    def get_available_densities(self) -> List[str]:
        """Get list of available layout densities"""
        return list(self.layout_density.keys())
    
    def get_template_preview_data(self, template_name: str) -> Dict[str, Any]:
        """Get template configuration for preview generation"""
        template_config = self.template_configurations.get(template_name, self.template_configurations['modern'])
        
        return {
            'name': template_config['name'],
            'layout_type': template_config['layout_type'],
            'description': f"Professional {template_config['layout_type'].replace('_', ' ')} layout with {template_config['section_style'].replace('_', ' ')} styling",
            'features': [
                f"{template_config['header_style'].replace('_', ' ').title()} header",
                f"{template_config['section_style'].replace('_', ' ').title()} sections",
                f"{template_config['bullet_style'].replace('_', ' ').title()}",
                f"{template_config['emphasis_style'].replace('_', ' ').title()}"
            ]
        }
